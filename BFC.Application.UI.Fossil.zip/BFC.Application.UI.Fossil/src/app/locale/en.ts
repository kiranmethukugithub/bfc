export const locale = {
  lang: 'en',
  dir: 'ltr',
  data: {
    Welcome: 'Welcome',

    Dashboard: {
      Title: 'Dashboard'
    },

    Samples: {

      Typeography: {
        Title: 'Typography'
      },

      Icons: {
        Title: 'Icons'
      }

    },

    Sidebar: {
      Dashboard: 'Dashboard',
      Samples: {
        Typography: 'Typography',
        Icons: 'Icons'
      }
    },
  }
};
