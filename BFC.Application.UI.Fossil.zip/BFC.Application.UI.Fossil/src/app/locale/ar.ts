export const locale = {
  lang: 'ar',
  dir: 'rtl',
  data: {
    Welcome: 'أهلا بك',

    Dashboard: {
      Title: 'لوحة القيادة'
    },

    Samples: {

      Typeography: {
        Title: 'نمط النص'
      },

      Icons: {
        Title: 'الرموز'
      }

    },

    Sidebar: {
      Dashboard: 'لوحة القيادة',
      Samples: {
        Typography: 'نمط النص',
        Icons: 'الرموز'
      }
    },
  }
};
