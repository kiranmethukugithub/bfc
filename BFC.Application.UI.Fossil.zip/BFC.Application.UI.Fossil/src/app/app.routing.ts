import { Routes } from '@angular/router';

import {
  // AuthGuard,
  EmptyLayoutComponent,
  MainLayoutComponent,
  Error503Component,
  Error500Component,
  Error404Component,
} from './core';

import { AuthGuard } from './core/guards/auth.guard';
import { DelayComponentLoadingResolver } from './shared/resolvers/delay-component-loading.resolver';
import { DocsLayoutComponent } from './core/layouts/docs/docs-layout.component';

// import { ACCORDION_ROUTES } from './samples/components/accordion/accordion.module';
// import { ICON_ROUTES } from './samples/components/icons/icons.module';

export const AppRoutes: Routes =
  [
    {
      path: '',
      component: MainLayoutComponent,
      canActivate: [AuthGuard],
      canActivateChild: [AuthGuard], // https://angular.io/guide/router#canactivatechild-guarding-child-routes
      children: [{
        path: '',
        redirectTo: '/dashboard',
        pathMatch: 'full',
      },
      {
        path: 'dashboard',
        loadChildren: './feature/dashboard/dashboard.module#DashboardModule',
        // resolve: { message: DelayComponentLoadingResolver }
      }
      ]
    },
    {
      path: '',
      component: EmptyLayoutComponent,
      children: [
        {
          path: 'error/404',
          component: Error404Component
        },
        {
          path: 'error/500',
          component: Error500Component
        },
        {
          path: 'error/503',
          component: Error503Component
        },
      ]
    },
    {
      path: 'docs',
      component: DocsLayoutComponent,
      canActivate: [AuthGuard],
      canActivateChild: [AuthGuard],
      loadChildren: './documentation/documentation.module#DocumentationModule'

      // children: [
      //   {
      //     path: 'accordion',
      //     children: ACCORDION_ROUTES
      //   },
      //   {
      //     path: 'icons',
      //     children: ICON_ROUTES
      //   },
      //   // {
      //   //   path: '**',
      //   //   redirectTo: 'accordion'
      //   // }
      // ]
    },
    {
      path: '**',
      redirectTo: 'error/404'
    }
  ];
