// import { Injectable } from '@angular/core';
// import { NgbTimeStruct2, NgbTimeAdapter2 } from 'app/lib/ngb-timepicker';

// /**
//  * Example of a String Time adapter
//  */
// @Injectable()
// export class NgbTimeStringAdapter extends NgbTimeAdapter2<string> {
//   fromModel(value: string): NgbTimeStruct2 {
//     if (!value) {
//       return null;
//     }
//     const split = value.split(':');
//     return {
//       hour: parseInt(split[0], 10),
//       minute: parseInt(split[1], 10),
//       second: parseInt(split[2], 10)
//     };
//   }

//   toModel(time: NgbTimeStruct2): string {
//     if (!time) {
//       return null;
//     }
//     return `${this.pad(time.hour)}:${this.pad(time.minute)}:${this.pad(time.second)}`;
//   }

//   private pad(i: number): string {
//     return i < 10 ? `0${i}` : `${i}`;
//   }
// }
