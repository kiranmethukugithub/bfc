export class ElementScrollUtils {
  public static hasVerticalScroll(node = null) {
    return this.hasScroll(node, 'vertical');
  }

  public static hasHorizontalScroll(node = null) {
    return this.hasScroll(node, 'horizontal');
  }

  public static hasScroll(node, axis) {
    axis = axis ? String(axis).toLowerCase() : '';

    const X = 'x';
    const Y = 'y';

    switch (axis) {
      case 'horizontal':
      case 'x':
        axis = X;
        break;
      default:
        axis = Y;
        break;
    }

    const windowInnerSize = axis === Y ? window.innerHeight : window.innerWidth,
      overflowProp = axis === Y ? 'overflowY' : 'overflowX',
      offsetSizeProp = axis === Y ? 'offsetHeight' : 'offsetWidth',
      scrollSizeProp = axis === Y ? 'scrollHeight' : 'scrollWidth';

    if (!node) {
      if (windowInnerSize) {
        const overflow = getComputedStyle(document.documentElement)[overflowProp];

        return document.body[offsetSizeProp] > windowInnerSize || overflow === 'scroll';
      } else {
        return (
          document.documentElement[scrollSizeProp] > document.documentElement[offsetSizeProp] ||
          document.body[scrollSizeProp] > document.body[offsetSizeProp]
        );
      }
    } else {
      return node[scrollSizeProp] > node[offsetSizeProp];
    }
  }
}
