import { NgModule, Component, Pipe, PipeTransform, WrappedValue } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Observable } from 'rxjs';

@Pipe({ name: 'numeric' })
export class NumericPipe implements PipeTransform {
  transform(currentNumericValue: string): any {
    if (!currentNumericValue) {
      return '';
    }
    return WrappedValue.wrap(currentNumericValue.replace(/\D/g, ''));
  }
}
