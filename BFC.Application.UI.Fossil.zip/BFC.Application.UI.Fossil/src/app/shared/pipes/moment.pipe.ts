import { NgModule, Component, Pipe, PipeTransform, WrappedValue } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { Observable } from 'rxjs';
import * as moment from 'moment';

@Pipe({ name: 'moment' })
export class MomentPipe implements PipeTransform {
  transform(datetimeoffset: string, format: string): any {

    if (!datetimeoffset) {
      return '';
    }

    if (format === '' || format === undefined || format === null) {
      format = 'MM/DD/YYYY HH:mmZ';
    }

    return WrappedValue.wrap(moment(datetimeoffset).format(format));
  }
}
