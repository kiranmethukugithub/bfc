import { PipeTransform, Pipe } from '@angular/core';

@Pipe({ name: 'objectKeys' })
export class ObjectKeysPipe implements PipeTransform {
  transform(value, args: string[]): any {
    const result = [];
    const keys = Object.keys(value);
    for (let i = 0; i < keys.length ; i++) {
      const enumKey = keys[i];
      const enumValue = value[enumKey];
      result.push({ key: enumKey, value: enumValue });
    }
    return result;
  }
}
