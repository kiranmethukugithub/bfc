import { Injectable } from '@angular/core';
import { Resolve } from '@angular/router';
import { of, Observable } from 'rxjs';
import { delay } from 'rxjs/operators';

@Injectable()
export class DelayComponentLoadingResolver implements Resolve<Observable<string>> {
  constructor() { }

  resolve() {
    return of('This should only be used to delay the loading of a route for testing purposes.').pipe(
      delay(2500)
    );
  }
}
