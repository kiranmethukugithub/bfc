import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

export interface Locale {
  dir: string;
  lang: string;
  data: Object;
}

@Injectable()
export class TranslationLoaderService {
  constructor(private translate: TranslateService) {  }

  public loadTranslations(...args: Locale[]): void {
    const locales = [...args];

    locales.forEach((locale) => {
      // Last parameter merges translations which collide.
      this.translate.setTranslation(locale.lang, locale.data, true);
    });
  }
}
