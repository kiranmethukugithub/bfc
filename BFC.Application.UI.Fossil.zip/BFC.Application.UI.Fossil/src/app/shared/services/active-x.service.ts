import { Injectable } from '@angular/core';
import { UserAgentUtils } from '../helpers/user-agent.utils';
import swal from 'sweetalert2';
import { OAuthService } from 'angular-oauth2-oidc';

@Injectable()
export class ActiveXService {
    private activeXObject: GKComSysDetails;
    private macAddress = '';
    private ipAddress = '';
    private machineName = '';
    private processorId = '';
    private printerName = '';

    public readonly isActiveXAvailable: boolean;

    constructor(private oAuthService: OAuthService) {
        console.log('ActiveXService constructor: ', this.isActiveXAvailable);
        // TODO Improve Check to see if user is logged in...
        // if (this.oAuthService.hasValidAccessToken() && this.oAuthService.hasValidIdToken()) {
        if (this.checkActiveXEnabled()) {
            this.isActiveXAvailable = true;
            console.log('ActiveXEnabled: ', this.isActiveXAvailable);
            this.machineName = this.activeXObject.GetSysName();
            this.ipAddress = this.activeXObject.GetLocIPAddress();
            this.macAddress = this.activeXObject.GetMACAddress();
            this.processorId = this.activeXObject.GetProcessorId();
            this.printerName = this.activeXObject.GetAllSysPrinterName();
        }
        // }
    }

    private checkActiveXEnabled(): boolean {

        console.log('checkActiveXEnabled');

        const controlNotInstalledMessage = `<span>The ActiveX Control was not found.<span><br/>
        <span>Please download and install it from</span>
        <a href="/assets/activeX/Fossil-ActiveX.msi">Here</a>`;

        const browserNotSupportedMessage = `<span>Only Internet Explorer supports ActiveX.<span><br/>
        <span>Certain functionality will be unavailable.</span><br/>`;

        const displayLimitedFunctionalityMessage = reason => {
            swal({
                title: 'Limited Functionality',
                type: 'warning',
                html: reason
            });
        };

        if (UserAgentUtils.isIE()) {
            try {
                this.activeXObject = new ActiveXObject('GKCom.SysDetails');
            } catch (e) {
                displayLimitedFunctionalityMessage(controlNotInstalledMessage);
                return false;
            }
        } else {
            displayLimitedFunctionalityMessage(browserNotSupportedMessage);
            return false;
        }

        return true;
    }

    getMACAddress(): string {
        return this.macAddress;
    }

    getIPAddress(): string {
        return this.ipAddress;
    }

    getMachineName(): string {
        return this.machineName;
    }

    getPrinterName(): string {
        return this.printerName;
    }

    getProcessorId(): string {
        return this.processorId;
    }
}
