import { AppConfig } from '../models/app-config.model';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { tap ,  catchError } from 'rxjs/operators';
import * as _ from 'lodash';

@Injectable()
export class ConfigService {

  private _config: AppConfig;

  onConfigChanged: BehaviorSubject<any>;

  constructor(private http: HttpClient) { }

  private init(config: AppConfig) {
    // Set the config
    this._config = config;

    // Create the behavior subject
    this.onConfigChanged = new BehaviorSubject(this._config);
  }

  load(url: string): Observable<any> {
    return this.http.get(url)
      .pipe(
        tap((jsonData: AppConfig) => this.init(jsonData)),
        catchError((error) => {
          // TODO Extend Error Messages - More Detail
          throw new Error(`Error retrieving configuration from '${url}':\n ${error}`);
        })
      );
  }

  getConfig(): AppConfig {
    return this._config;
  }

  /**
   * Set the new config from given object
   *
   * @param config
   */
  setConfig(newConfig: AppConfig): void {
    // Merge the config
    this._config = _.merge({}, this._config, newConfig);

    // Trigger the event
    this.onConfigChanged.next(this._config);
  }
}
