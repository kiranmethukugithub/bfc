import { EventEmitter, Injectable } from '@angular/core';
import { HubConnection, HubConnectionBuilder } from '@aspnet/signalr';
import { ChatMessage } from 'app/shared/models/chat-message.model';
import { ConfigService } from './config.service';

const maxConnectionRetries = 5;
const connectionRetryTimeout = 5000;

@Injectable()
export class SystemControlService {
  messageReceived = new EventEmitter<ChatMessage>();
  connectionEstablished = new EventEmitter<Boolean>();

  private connectionIsEstablished = false;
  private hubConnection: HubConnection;
  private connectionRetries = 0;

  constructor(private configService: ConfigService) {
    this.createConnection();
    this.registerOnServerEvents();
    this.startConnection();
  }

  private createConnection() {
    this.hubConnection = new HubConnectionBuilder()
      .withUrl(this.configService.getConfig().serviceUrl + '/hubs/system')
      .build();
  }

  private startConnection(): void {
    this.hubConnection
      .start()
      .then(() => {
        this.connectionIsEstablished = true;
        console.log('Hub connection started');
        this.connectionEstablished.emit(true);
      })
      .catch(err => {
        if (this.connectionRetries < maxConnectionRetries) {

          // Log message and increment retry counter
          this.connectionRetries++;
          console.log(`Error while establishing connection, retrying... (Attempt: ${this.connectionRetries})`);

          // Retry connection
          setTimeout(() => this.startConnection(), connectionRetryTimeout);

        } else {
          console.log(`Error while establishing connection, reached maximum retry attempts.`);
        }
      });
  }

  private registerOnServerEvents(): void {
    this.hubConnection.on('Send', (data: any) => {
      this.messageReceived.emit(data);
    });
  }
}
