import { AbstractControl, ValidatorFn } from '@angular/forms';

export class PasswordValidator {

  static Match(abstractControl: AbstractControl) {
    const password = abstractControl.get('password').value; // to get value in input tag
    const confirmPassword = abstractControl.get('confirmPassword').value; // to get value in input tag
    if (password !== confirmPassword) {
      abstractControl.get('confirmPassword').setErrors({ PasswordMatch: true });
    } else {
      abstractControl.get('confirmPassword').setErrors({ PasswordMatch: false });
      return null;
    }
  }


  // Borrowed from (modified): https://github.com/Nightapes/ngx-validators/blob/master/src/password/password-validators.ts
  public static repeatCharacterRegexRule(repeatCount: number) {
    const validator = (control: AbstractControl): { [key: string]: any } => {
      if (isNotPresent(control)) { return undefined; }
      const repeatDec = repeatCount - 1;
      const pattern = '([^\\x00-\\x1F])\\1{' + repeatDec + '}';
      if (control.value !== '' && new RegExp(pattern).test(control.value)) {
        return { 'repeatCharacterRegexRule': { 'repeatCount': repeatCount } };
      }
      return undefined;
    };
    return validator;
  }

  public static allowedCharacterRule(allowedChars: string[]): ValidatorFn {
    const validator = (control: AbstractControl): { [key: string]: any } => {
      if (isNotPresent(control)) { return undefined; }
      const value: string = control.value;
      let valid = true;
      const invalidChars: string[] = [];

      for (const char of value) {
        if (allowedChars.indexOf(char) === -1) {
          valid = false;
          if (invalidChars.indexOf(char) === -1) {
            invalidChars.push(char);
          }
        }
      }
      if (!valid) {
        return { 'allowedCharacterRule': { 'invalidChars': invalidChars, 'allowedChars': allowedChars } };
      }
      return undefined;
    };
    return validator;
  }

  public static alphabeticalCharacterRule(amount: number): ValidatorFn {
    const validator = (control: AbstractControl): { [key: string]: any } => {
      if (isNotPresent(control)) { return undefined; }
      const value: string = control.value;
      if (value.length === 0) {
        return undefined;
      }
      const pattern = /[^A-Za-z]+/g;
      const stripped = value.replace(pattern, '');
      if (stripped.length < amount) {
        return { 'alphabeticalCharacterRule': { 'required': amount, 'actual': stripped.length } };
      }
      return undefined;
    };
    return validator;
  }

  public static digitCharacterRule(amount: number): ValidatorFn {
    const validator = (control: AbstractControl): { [key: string]: any } => {
      if (isNotPresent(control)) { return undefined; }
      const value: string = control.value;
      if (value.length === 0) {
        return undefined;
      }
      const pattern = /[^0-9\.]+/g;
      const stripped = value.replace(pattern, '');
      if (stripped.length < amount) {
        return { 'digitCharacterRule': { 'required': amount, 'actual': stripped.length } };
      }
      return undefined;
    };
    return validator;
  }

  public static lowercaseCharacterRule(amount: number): ValidatorFn {
    const validator = (control: AbstractControl): { [key: string]: any } => {
      if (isNotPresent(control)) { return undefined; }
      const value: string = control.value;
      if (value.length === 0) {
        return undefined;
      }
      const pattern = /[^a-z]+/g;
      const stripped = value.replace(pattern, '');
      if (stripped.length < amount) {
        return { 'lowercaseCharacterRule': { 'required': amount, 'actual': stripped.length } };
      }
      return undefined;
    };
    return validator;
  }

  public static uppercaseCharacterRule(amount: number): ValidatorFn {
    const validator = (control: AbstractControl): { [key: string]: any } => {
      if (isNotPresent(control)) { return undefined; }
      const value: string = control.value;
      if (value.length === 0) {
        return undefined;
      }
      const pattern = /[^A-Z]+/g;
      const stripped = value.replace(pattern, '');
      if (stripped.length < amount) {
        return { 'uppercaseCharacterRule': { 'required': amount, 'actual': stripped.length } };
      }
      return undefined;
    };
    return validator;
  }

  public static specialCharacterRule(amount: number): ValidatorFn {
    const validator = (control: AbstractControl): { [key: string]: any } => {
      if (isNotPresent(control)) { return undefined; }
      const value: string = control.value;
      if (value.length === 0) {
        return undefined;
      }
      const pattern = /[\w\s]+/g;
      const stripped = value.replace(pattern, '');
      if (stripped.length < amount) {
        return { 'specialCharacterRule': { 'required': amount, 'actual': stripped.length } };
      }
      return undefined;
    };
    return validator;
  }

  public static mismatchedPasswords(passwordControlName?: string, confirmPasswordControlName?: string): ValidatorFn {
    const validator = (group: AbstractControl): { [key: string]: any } => {
      const newPasswordValue = group.get(passwordControlName ? passwordControlName : 'password').value;
      const newPasswordConfirmValue = group.get(confirmPasswordControlName ? confirmPasswordControlName : 'confirmPassword').value;
      if (newPasswordValue !== newPasswordConfirmValue) {
        addError(group.get(confirmPasswordControlName ? confirmPasswordControlName : 'confirmPassword'), 'mismatchedPasswords', true);

        return { 'mismatchedPasswords': true };
      } else {
        removeError(group.get(confirmPasswordControlName ? confirmPasswordControlName : 'confirmPassword'), 'mismatchedPasswords');
      }
      return undefined;

    };
    return validator;
  }
}

/* Helper Methods  */

function isNotPresent(control: AbstractControl): boolean {
  const value = control.value;
  if (value === undefined || value === null) {
    return true;
  }
  return value !== '' ? false : true;
}

function addError(control: AbstractControl, errorId: string, value: any) {
  if (!control.errors) {
    control.setErrors({ [errorId]: value });
  } else if (!control.hasError(errorId)) {
    control.errors[errorId] = value;
  }
}

function removeError(control: AbstractControl, errorId: string) {
  if (control.errors && control.hasError(errorId)) {
    delete control.errors[errorId];
  }
}
