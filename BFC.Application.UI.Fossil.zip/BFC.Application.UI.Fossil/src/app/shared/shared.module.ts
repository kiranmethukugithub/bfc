import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OnlyNumberDirective, PerfectScrollbarDirective } from './directives';
import { NumericPipe, MomentPipe, BooleanPipe, ObjectKeysPipe } from './pipes';
import { SignalRService, SystemControlService, SplashScreenService, ApiTestService } from './services';
import { SourceCodeComponent } from './components';
import { ActiveXService } from './services/active-x.service';

@NgModule({
  imports: [CommonModule],
  // Shared Components / Directives / Models
  declarations: [
    OnlyNumberDirective,
    PerfectScrollbarDirective,
    NumericPipe,
    MomentPipe,
    BooleanPipe,
    ObjectKeysPipe,
    SourceCodeComponent
  ],
  exports: [
    OnlyNumberDirective,
    PerfectScrollbarDirective,
    NumericPipe,
    MomentPipe,
    BooleanPipe,
    ObjectKeysPipe,
    SourceCodeComponent
  ]
})
export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      // Shared Services
      providers: [
        SignalRService,
        SystemControlService,
        SplashScreenService,
        ApiTestService,
        ActiveXService
      ]
    };
  }
}
