export interface AppConfig {
  version?: string;
  language?: string;
  serviceUrl?: string;
  customScrollbar?: boolean;
  auth?: {
    issuer?: string;
    redirectUri?: string;
    clientId?: string;
    logoutUrl?: string;
    scope?: string;
    requireHttps?: boolean;
    requestAccessToken?: boolean;
    showDebugInformation?: boolean;
    oidc?: boolean;
  };
  logging?: {
    levelMin?: string;
    levelMax?: string;
  };

  userIdle?: {
      enabled?: boolean,
      idle: 60,
      timeout: 30,
      warningInterval: 60
  };
}
