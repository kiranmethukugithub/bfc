export class UserAgentUtils {
    /**
     * Detects if theuser agent is IE
     * @param userAgent
     */
    public static isIE(): boolean {
        return navigator.userAgent.indexOf('MSIE ') > -1 || navigator.userAgent.indexOf('Trident/') > -1;
    }

    public static supportsServiceWorker(): boolean {
        return ('ServiceWorker' in navigator) && !UserAgentUtils.isIE();
    }
}
