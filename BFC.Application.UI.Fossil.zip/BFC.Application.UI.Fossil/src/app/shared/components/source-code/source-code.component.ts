import { Component, ContentChild, ElementRef, Input, OnDestroy, OnInit, OnChanges, SimpleChanges, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import * as Prism from 'prismjs/prism';
import './prism-languages';
import { SourceCodeThemes } from './source-code-themes.enum';

@Component({
    selector: 'app-source-code',
    template: '<pre class="language-{{ lang }}"><code #code class="language-{{ lang }}"></code></pre>',
    styleUrls: ['./source-code.component.scss']
})
export class SourceCodeComponent implements OnInit, OnDestroy, OnChanges {
    // Code Element
    @ViewChild('code') codeEl: ElementRef<HTMLElement>;

    @Input() code = '';

    // Lang
    @Input()
    lang: 'html' | 'bash' | 'prism-c' | 'prism-cpp' | 'csharp' | 'css' |
    'diff' | 'markup' | 'markup-templating' | 'java' | 'javascript' |
    'json' | 'perl' | 'php' | 'python' | 'sass' | 'scss' | 'typescript' = 'html';

    @Input()
    theme: SourceCodeThemes = SourceCodeThemes.Default;

    /**
     * Constructor
     *
     * @param {ElementRef} _elementRef
     * @param {HttpClient} _httpClient
     */
    constructor() { }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void {
        this.reinitialise();
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.reinitialise();
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void { }

    protected reinitialise() {
        if (this.code) {
            // Highlight it
            this.highlight(this.code);
        }
    }

    /**
     * Highlight the given source code
     *
     * @param sourceCode
     */
    protected highlight(sourceCode): void {
        // Split the source into lines
        const sourceLines = sourceCode.split('\n');

        // Remove the first and the last line of the source
        // code if they are blank lines. This way, the html
        // can be formatted properly
        if (!sourceLines[0].trim()) {
            sourceLines.shift();
        }

        if (!sourceLines[sourceLines.length - 1].trim()) {
            sourceLines.pop();
        }

        // Find the first non-whitespace char index in
        // the first line of the source code
        const indexOfFirstChar = sourceLines[0].search(/\S|$/);

        // Generate the trimmed source
        let source = '';

        // Iterate through all the lines
        sourceLines.forEach((line, index) => {

            // Trim the beginning white space depending on the index
            // and concat the source code
            source = source + line.substr(indexOfFirstChar, line.length);

            // If it's not the last line...
            if (index !== sourceLines.length - 1) {
                // Add a line break at the end
                source = source + '\n';
            }
        });

        // Generate the highlighted code
        this.codeEl.nativeElement.innerHTML = Prism.highlight(source, Prism.languages[this.lang]);

        // Replace the innerHTML of the component with the highlighted code
        // this._elementRef.nativeElement.innerHTML =
        //     '<pre><code class="highlight language-' + this.lang + '">' + highlightedCode + '</code></pre>';

        this.codeEl.nativeElement.setAttribute('theme', this.theme);
    }
}

