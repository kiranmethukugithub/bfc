export enum SourceCodeThemes {
  Coy = 'coy',
  Dark = 'dark',
  Default = 'default',
  Funky = 'funky',
  Okaidia = 'okaidia',
  SolarizedLight = 'solarizedlight',
  Tomorrow = 'tomorrow',
  Twightlight = 'twightlight'
}
