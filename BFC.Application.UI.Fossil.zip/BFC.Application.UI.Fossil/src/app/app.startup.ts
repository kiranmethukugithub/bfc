/* This class startup logic & helper functions for configuring globally available modules */

import { environment } from '../environments/environment';
import { TranslateService } from '@ngx-translate/core';

// Shared
import { ConfigService, TranslationLoaderService } from 'app/shared';


// TODO Retrieve th9is from a server..
import { locale as englishLocale } from './locale/en';
import { locale as arabicLocale } from './locale/ar';

/**
 * Runs on application startup to initialise services.
 */
export function appInitializer(configService: ConfigService,
  translateService: TranslateService,
  translationLoaderService: TranslationLoaderService
) {
  return () => new Promise((resolve) => {

    if (environment.production) {
      console.log('Production mode enabled!');
    }

    configService.load(environment.configFile).subscribe(() => {

      // TODO Move out of subscription into call for languages from server and zip observables.
      // Add languages // TODO Get a list of languages from the server.
      translateService.addLangs(['en', 'ar']);

      // Set the navigation translations
      translationLoaderService.loadTranslations(englishLocale, arabicLocale);

      // Use a language
      translateService.use(englishLocale.lang);

      // Set the default language
      translateService.setDefaultLang(englishLocale.lang);

      // TODO Move into a common location?
      configService.onConfigChanged.subscribe((newConfig) => {
        translateService.use(newConfig.language);
      });

      resolve();
    });
  });
}

/**
 * Detects the origin URI for the client application using a common Javascript polyfill from modernizr.
 * Link: https://tosbourn.com/a-fix-for-window-location-origin-in-internet-explorer/
 */
export function originFactory() {
  const wl = window.location;
  if (wl.origin) {
    return wl.origin;
  }
  const polyfill = wl.protocol + '//' + wl.hostname + (wl.port ? ':' + wl.port : '');
  return polyfill;
}
