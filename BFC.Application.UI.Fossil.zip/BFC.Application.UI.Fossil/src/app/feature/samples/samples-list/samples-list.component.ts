import { Component, OnInit } from '@angular/core';
import {
    globalAnimations
} from 'app/shared';

@Component({
    selector: 'app-samples-list',
    templateUrl: './samples-list.component.html',
    styleUrls: ['./samples-list.component.scss'],
    animations: globalAnimations
})
export class SamplesListComponent implements OnInit {
    ngOnInit() { }
}
