import { Component } from '@angular/core';
import { globalAnimations } from 'app/shared';

@Component({
  selector: 'app-typography-sample',
  templateUrl: './typography-sample.component.html',
  styleUrls: ['./typography-sample.component.scss'],
  animations: globalAnimations
})
export class TypographySampleComponent {
  constructor() { }
}
