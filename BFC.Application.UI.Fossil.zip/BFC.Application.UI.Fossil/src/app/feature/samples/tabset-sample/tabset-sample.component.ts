import { Component } from '@angular/core';
import { globalAnimations } from 'app/shared';

@Component({
  selector: 'app-tabset-sample',
  templateUrl: './tabset-sample.component.html',
  styleUrls: ['./tabset-sample.component.scss'],
  animations: globalAnimations
})
export class TabsetSampleComponent {
  constructor() { }
}
