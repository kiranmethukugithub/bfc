import { Routes } from '@angular/router';

import { TypographySampleComponent } from './typography-sample/typography-sample.component';
import { IconsSampleComponent } from './icons-sample/icons-sample.component';
import { SamplesListComponent } from './samples-list/samples-list.component';
import { SourceCodeSampleComponent } from './source-code-sample/source-code-sample.component';
import { TabsetSampleComponent } from './tabset-sample/tabset-sample.component';

export const SamplesRoutes: Routes = [
  {
    path: '',
    component: SamplesListComponent
  },
  {
    path: 'typography',
    component: TypographySampleComponent,
  },
  {
    path: 'icons',
    component: IconsSampleComponent,
  },
  {
    path: 'source-code',
    component: SourceCodeSampleComponent,
  },
  {
    path: 'tabset',
    component: TabsetSampleComponent,
  }
];
