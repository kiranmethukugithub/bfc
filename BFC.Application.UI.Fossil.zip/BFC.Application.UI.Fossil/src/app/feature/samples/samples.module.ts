import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { SamplesRoutes } from './samples.routing';
import { TypographySampleComponent } from './typography-sample/typography-sample.component';
import { IconsSampleComponent } from './icons-sample/icons-sample.component';
import { SharedModule } from 'app/shared';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { SamplesListComponent } from './samples-list/samples-list.component';
import { SourceCodeSampleComponent } from './source-code-sample/source-code-sample.component';
import { TabsetSampleComponent } from './tabset-sample/tabset-sample.component';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(SamplesRoutes),
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    TranslateModule.forChild(),
    AngularFontAwesomeModule
  ],
  declarations: [
    SamplesListComponent,
    TypographySampleComponent,
    IconsSampleComponent,
    SourceCodeSampleComponent,
    TabsetSampleComponent
  ]
})

export class SamplesModule { }
