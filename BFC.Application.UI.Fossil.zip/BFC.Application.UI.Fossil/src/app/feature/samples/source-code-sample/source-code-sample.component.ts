import { Component } from '@angular/core';
import { globalAnimations, SourceCodeThemes } from 'app/shared';

@Component({
  selector: 'app-source-code-sample',
  templateUrl: './source-code-sample.component.html',
  styleUrls: ['./source-code-sample.component.scss'],
  animations: globalAnimations
})
export class SourceCodeSampleComponent {

  SourceCodeThemes = SourceCodeThemes;
  selectedTheme: SourceCodeThemes = SourceCodeThemes.Dark;
  constructor() {
  }
}
