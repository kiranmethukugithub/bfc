import { Component, OnInit } from '@angular/core';
import {
  globalAnimations, ApiTestService, ActiveXService,
  // ComponentLoadingState,
  // UserPinExpiryInfo,
  // UsersAndProfilesService,
  // SessionService,
  // UserSessionModel,
  // PinManagementModalComponent
} from 'app/shared';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  animations: globalAnimations
})
export class DashboardComponent implements OnInit {
  // Make these Available to the template
  // ComponentLoadingState = ComponentLoadingState;
  Math = Math;

  // Member variables
  // loadingState = ComponentLoadingState.Loading;
  // userSession: UserSessionModel;
  // userPinExpiryInfo: UserPinExpiryInfo;
  modal: NgbModalRef;

  // TODO remove once testing is done
  ipAaddress: string;
  macAddress: string;
  machineName:string;
  printerName: string;
  processorId: string;

  constructor(
    // private sessionService: SessionService,
    // private usersAndProfilesService: UsersAndProfilesService,
    private modalService: NgbModal,
    private toastrService: ToastrService,
    private apiTestService: ApiTestService,
    private activeXService: ActiveXService
  ) { }

  ngOnInit() {
this.ipAaddress = this.activeXService.getIPAddress();
this.macAddress = this.activeXService.getMACAddress();
this.machineName = this.activeXService.getMachineName();
this.printerName = this.activeXService.getPrinterName();
this.processorId = this.activeXService.getProcessorId();

    this.loadPinExpiryInfo();
  }

  // TODO Either dont display the notice when the pin has expired (as the modal will have been displayed automatically)
  // or find a way to have the modal inform the dashboard the pin is updated.
  get showUserPinExpirationNotice() {
    return false;
    // return this.userPinExpiryInfo
    //     ? !this.userPinExpiryInfo.isPinExpired && this.userPinExpiryInfo.daysToExpiry <= this.userPinExpiryInfo.expiryNotificationDays
    //     : false;
  }

  loadExpiredPinModal() {
    // this.modal = this.modalService.open(PinManagementModalComponent, { size: 'sm', windowClass: 'modal-center', backdrop: false });
    // this.modal.componentInstance.isEditMode = true;
    // this.modal.result.then(() => {
    //     this.loadPinExpiryInfo();
    // }).catch(error => {});
  }

  private loadPinExpiryInfo() {
    // this.loadingState = ComponentLoadingState.Loading;
    // this.userSession = this.sessionService.GetUserSession();

    // this.usersAndProfilesService.getUserPinExpiryInfo(this.userSession.username).subscribe(result => {
    //     this.userPinExpiryInfo = result;
    //     this.loadingState = ComponentLoadingState.Complete;
    // });
  }

  showToast() {
    this.toastrService.info('Toast to you!');
  }

  get() {
    this.apiTestService.get().subscribe(x => alert(x)); // TODO Obviosuly this is just to test
  }
}
