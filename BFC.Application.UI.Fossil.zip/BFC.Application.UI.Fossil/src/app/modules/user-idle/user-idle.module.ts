import { ModuleWithProviders, NgModule } from '@angular/core';
import { UserIdleConfig } from './user-idle-config.model';

@NgModule({
  imports: []
})
export class UserIdleModule {
  static forRoot(config?: UserIdleConfig): ModuleWithProviders {
    if (config) {
      return {
        ngModule: UserIdleModule,
        providers: [
          { provide: UserIdleConfig, useValue: config }
        ]
      };
    } else {
      return {
        ngModule: UserIdleModule
      };
    }
  }
}
