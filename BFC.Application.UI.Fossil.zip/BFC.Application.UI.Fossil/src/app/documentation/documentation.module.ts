import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { DocRoutes } from "./documentation.routing";
import { SharedModule } from "app/shared";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { TranslateModule } from "@ngx-translate/core";
import {
  AccordionDocModule,
  FontAwesomeDocModule,
  ButtonsDocModule,
  CarouselDocModule,
  CollapseDocModule,
  PaginationDocModule,
  DropdownDocModule,
  DatepickerDocModule,
  ModalDocModule,
  AlertDocModule,
  TableDocModule,
  PopoverDocModule,
  TabsetDocModule,
  ProgressbarDocModule,
  RatingDocModule,
  TimepickerDocModule,
  TooltipDocModule,
  TypeaheadDocModule,
  IdleDocModule,
  ToastrDocModule
} from "./components";

import { StackblitzExampleLoaderService } from "./shared/stackblitz-example-loader.service";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { PinkToast } from "./components/toastr/demos/custom-pink-toast/custom-pink-toast";
import { NotyfToast } from "./components/toastr/demos/custom-notyf-toast/custom-notyf-toasts";

@NgModule({
  imports: [
    SharedModule,
    CommonModule,
    RouterModule.forChild(DocRoutes),
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    TranslateModule.forChild(),

    AccordionDocModule,
    AlertDocModule,
    ButtonsDocModule,
    CarouselDocModule,
    CollapseDocModule,
    DatepickerDocModule,
    DropdownDocModule,
    FontAwesomeDocModule,
    ModalDocModule,
    PaginationDocModule,
    PopoverDocModule,
    ProgressbarDocModule,
    RatingDocModule,
    TableDocModule,
    TabsetDocModule,
    TimepickerDocModule,
    TooltipDocModule,
    TypeaheadDocModule,
    IdleDocModule,
    ToastrDocModule
  ],
  declarations: [],
  providers: [StackblitzExampleLoaderService],
  entryComponents: []
})
export class DocumentationModule {}
