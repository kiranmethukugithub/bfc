import { NgModule } from '@angular/core';

import { ComponentWrapperComponent, DocumentationSharedModule, NgbdDemoList, NgbdExamplesPage, NgbdDemoListConfig } from '../../shared';
import { NgbdCollapseBasic } from './demos/basic/collapse-basic';

const DEMO_DIRECTIVES = [NgbdCollapseBasic];

const DEMOS: NgbdDemoListConfig = {
  basic: {
    title: 'Collapse',
    type: NgbdCollapseBasic,
    code: require('!!raw-loader!./demos/basic/collapse-basic'),
    markup: require('!!raw-loader!./demos/basic/collapse-basic.html')
  }
};

export const COLLAPSE_ROUTES = [
  { path: '', pathMatch: 'full', redirectTo: 'examples' },
  {
    path: '',
    component: ComponentWrapperComponent,
    children: [
      { path: 'examples', component: NgbdExamplesPage },
      // { path: 'api', component: NgbdApiPage }
    ]
  }
];

@NgModule({
  imports: [DocumentationSharedModule],
  declarations: DEMO_DIRECTIVES,
  entryComponents: DEMO_DIRECTIVES
})
export class CollapseDocModule {
  constructor(demoList: NgbdDemoList) {
    demoList.register('collapse', DEMOS);
  }
}
