import { ChangeDetectionStrategy, Component } from '@angular/core';

import { NgbdDemoList, NgbdOverview } from '../../../shared';

@Component({
  selector: 'ngbd-table-overview',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './table-overview.component.html',
  host: {
    '[class.overview]': 'true'
  }
})
export class NgbdTableOverviewComponent {

  bootstrapVersion = "4.X.X";

  sections: NgbdOverview = {};

  constructor(demoList: NgbdDemoList) {
    this.sections = demoList.getOverviewSections('table');
  }
}
