import { NgModule } from '@angular/core';

import { ComponentWrapperComponent, DocumentationSharedModule, NgbdDemoList, NgbdExamplesPage, NgbdDemoListConfig } from '../../shared';
import { NgbdTableBasic } from './demos/basic/table-basic';
import { NgbdSortableHeader as NgbdSortableHeader1, NgbdTableSortable } from './demos/sortable/table-sortable';
import { NgbdTableFiltering } from './demos/filtering/table-filtering';
import { NgbdTablePagination } from './demos/pagination/table-pagination';
import { NgbdTableComplete } from './demos/complete/table-complete';
import { NgbdSortableHeader as NgbdSortableHeader2 } from './demos/complete/sortable.directive';
import { NgbdTableOverviewComponent } from './overview/table-overview.component';
import { NgbdTableOverviewDemo } from './overview/demo/table-overview-demo.component';
import { SharedModule } from 'app/shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const DEMO_DIRECTIVES = [
  NgbdTableBasic, NgbdTableSortable, NgbdTableFiltering, NgbdTablePagination, NgbdTableComplete
];

const OVERVIEW = {
  'why-not': 'Why not?',
  'examples': 'Code examples'
};

const DEMOS = {
  basic: {
    title: 'Basic table',
    type: NgbdTableBasic,
    code: require('!!raw-loader!./demos/basic/table-basic'),
    markup: require('!!raw-loader!./demos/basic/table-basic.html')
  },
  sortable: {
    title: 'Sortable table',
    type: NgbdTableSortable,
    code: require('!!raw-loader!./demos/sortable/table-sortable'),
    markup: require('!!raw-loader!./demos/sortable/table-sortable.html')
  },
  filtering: {
    title: 'Search and filtering',
    type: NgbdTableFiltering,
    code: require('!!raw-loader!./demos/filtering/table-filtering'),
    markup: require('!!raw-loader!./demos/filtering/table-filtering.html')
  },
  pagination: {
    title: 'Pagination',
    type: NgbdTablePagination,
    code: require('!!raw-loader!./demos/pagination/table-pagination'),
    markup: require('!!raw-loader!./demos/pagination/table-pagination.html')
  },
  complete: {
    title: 'Complete example',
    type: NgbdTableComplete,
    code: require('!!raw-loader!./demos/complete/table-complete'),
    markup: require('!!raw-loader!./demos/complete/table-complete.html')
  }
};

export const TABLE_ROUTES = [
  { path: '', pathMatch: 'full', redirectTo: 'overview' },
  {
    path: '',
    component: ComponentWrapperComponent,
    data: { OVERVIEW },
    children: [
      { path: 'overview', component: NgbdTableOverviewComponent },
      { path: 'examples', component: NgbdExamplesPage }
    ]
  }
];

@NgModule({
  imports: [
    SharedModule,
    DocumentationSharedModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [
    DEMO_DIRECTIVES,
    NgbdSortableHeader1,
    NgbdSortableHeader2,
    NgbdTableOverviewComponent,
    NgbdTableOverviewDemo
  ],
  entryComponents: DEMO_DIRECTIVES
})
export class TableDocModule {
  constructor(demoList: NgbdDemoList) {
    demoList.register('table', DEMOS, OVERVIEW);
  }
}
