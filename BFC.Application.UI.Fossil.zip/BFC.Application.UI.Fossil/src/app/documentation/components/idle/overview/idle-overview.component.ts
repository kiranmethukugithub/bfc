import { ChangeDetectionStrategy, Component } from '@angular/core';

import { NgbdDemoList, NgbdOverview } from '../../../shared';

@Component({
  selector: 'idle-overview',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './idle-overview.component.html',
  host: {
    '[class.overview]': 'true'
  }
})

export class IdleOverviewComponent {

  sections: NgbdOverview = {};

  constructor(demoList: NgbdDemoList) {
    this.sections = demoList.getOverviewSections('idle');
  }
}
