import { NgModule } from '@angular/core';

import { ComponentWrapperComponent, DocumentationSharedModule, NgbdDemoList, NgbdExamplesPage, NgbdDemoListConfig } from '../../shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared';
import { IdleOverviewComponent } from './overview/idle-overview.component';
import { IdleBasic } from './demos/basic/basic';


const DEMO_DIRECTIVES = [
  IdleBasic
];

const OVERVIEW = {
  'basic-usage': 'Basic Usage',
  'getting-date': 'Getting/setting a date',
  'date-model': 'Date model and format',
  navigation: 'Moving around',
  'limiting-dates': 'Disabling and limiting dates',
  'day-template': 'Day display customization',
  'footer-template': 'Custom footer',
  range: 'Range selection',
  i18n: 'Internationalization',
  'keyboard-shortcuts': 'Keyboard shortcuts'
};

const DEMOS: NgbdDemoListConfig = {
  basic: {
    title: 'Basic Usage',
    type: IdleBasic,
    code: require('!!raw-loader!./demos/basic/basic'),
    markup: require('!!raw-loader!./demos/basic/basic.html')
  }
};

export const IDLE_ROUTES = [
  { path: '', pathMatch: 'full', redirectTo: 'overview' },
  {
    path: '',
    component: ComponentWrapperComponent,
    data: { OVERVIEW },
    children: [
      { path: 'overview', component: IdleOverviewComponent },
      // { path: 'examples', component: NgbdExamplesPage },
    ]
  }
];

@NgModule({
  imports: [
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    DocumentationSharedModule
  ],
  declarations: [
    ...DEMO_DIRECTIVES,
    IdleOverviewComponent
  ],
  entryComponents: [...DEMO_DIRECTIVES]
})
export class IdleDocModule {
  constructor(demoList: NgbdDemoList) {
    demoList.register('idle', DEMOS, OVERVIEW);
  }
}
