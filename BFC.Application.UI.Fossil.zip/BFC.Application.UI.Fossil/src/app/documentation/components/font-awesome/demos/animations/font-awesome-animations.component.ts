import { Component } from '@angular/core';

@Component({
  selector: 'app-demo-font-awesome-animations',
  templateUrl: './font-awesome-animations.component.html',
})
export class FontAwesomeAnimationsComponent {
  // animation: 'spin' | 'pulse' = 'pulse';
}
