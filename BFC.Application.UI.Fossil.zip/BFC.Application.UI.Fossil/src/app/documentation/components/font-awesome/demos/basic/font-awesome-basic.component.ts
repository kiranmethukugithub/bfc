import { Component } from '@angular/core';

@Component({
  selector: 'app-font-awesome-basic.component',
  templateUrl: './font-awesome-basic.component.html',
})
export class FontAwesomeBasicComponent {

}
