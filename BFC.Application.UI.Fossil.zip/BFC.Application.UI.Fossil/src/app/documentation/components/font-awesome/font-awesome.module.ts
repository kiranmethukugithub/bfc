import { NgModule } from '@angular/core';

import { ComponentWrapperComponent, NgbdDemoListConfig, NgbdExamplesPage } from '../../shared';
import { DocumentationSharedModule, NgbdDemoList } from '../../shared';

import { FontAwesomeOverviewComponent } from './overview/font-awesome-overview/font-awesome-overview.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
// import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FontAwesomeBasicComponent } from './demos/basic/font-awesome-basic.component';
import { FontAwesomeAnimationsComponent } from './demos/animations/font-awesome-animations.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const DEMO_COMPONENTS = [
  FontAwesomeBasicComponent,
  FontAwesomeAnimationsComponent
];

declare let require: any;

const DEMOS: NgbdDemoListConfig = {
  basic: {
    title: 'Basic usage',
    code: require('!raw-loader!./demos/basic/font-awesome-basic.component'),
    markup: require('!raw-loader!./demos/basic/font-awesome-basic.component.html'),
    type: FontAwesomeBasicComponent
  },
  animations: {
    title: 'Animations',
    code: require('!raw-loader!./demos/animations/font-awesome-animations.component'),
    markup: require('!raw-loader!./demos/animations/font-awesome-animations.component.html'),
    type: FontAwesomeAnimationsComponent
  }
};

const OVERVIEW = {
  'basic-usage': 'Basic Usage',
  'config': 'Configuration',
};

export const FONTAWESOME_ROUTES = [
  { path: '', pathMatch: 'full', redirectTo: 'overview' },
  { path: '',
    component: ComponentWrapperComponent,
    children: [
      { path: 'overview', component: FontAwesomeOverviewComponent },
      { path: 'examples', component: NgbdExamplesPage },
      // { path: 'api', component: NgbdApiPage }
    ]
  }
];

@NgModule({
  imports: [
    // BrowserModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AngularFontAwesomeModule,
    DocumentationSharedModule
  ],
  declarations: [
    ...DEMO_COMPONENTS,
    FontAwesomeOverviewComponent
  ],
  entryComponents: [
    ...DEMO_COMPONENTS,
  ]
})
export class FontAwesomeDocModule {
  constructor(demoList: NgbdDemoList) {
    demoList.register('font-awesome', DEMOS, OVERVIEW);
  }
}
