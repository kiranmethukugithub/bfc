import { Component } from '@angular/core';

@Component({
  selector: 'ngbd-alert-custom',
  templateUrl: './alert-custom.html',
  styleUrls: ['./alert-custom.scss']
})
export class NgbdAlertCustom {}
