import { NgModule } from "@angular/core";

import {
  ComponentWrapperComponent,
  DocumentationSharedModule,
  NgbdDemoList,
  NgbdExamplesPage,
  NgbdDemoListConfig
} from "../../shared";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { SharedModule } from "app/shared";
import { ToastrOverviewComponent } from "./overview/toastr-overview.component";
import { ToastrBasic } from "./demos/basic/basic";
import { PinkToast } from "./demos/custom-pink-toast/custom-pink-toast";
import { NotyfToast } from "./demos/custom-notyf-toast/custom-notyf-toasts";

const DEMO_DIRECTIVES = [ToastrBasic];

const OVERVIEW = {
  "basic-usage": "Basic Usage"
};

const DEMOS: NgbdDemoListConfig = {
  basic: {
    title: "Basic Usage",
    type: ToastrBasic,
    code: require("!!raw-loader!./demos/basic/basic"),
    markup: require("!!raw-loader!./demos/basic/basic.html")
  }
};

export const TOASTR_ROUTES = [
  { path: "", pathMatch: "full", redirectTo: "overview" },
  {
    path: "",
    component: ComponentWrapperComponent,
    data: { OVERVIEW },
    children: [
      { path: "overview", component: ToastrOverviewComponent }
      // { path: 'examples', component: NgbdExamplesPage },
    ]
  }
];

@NgModule({
  imports: [
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    DocumentationSharedModule
  ],
  declarations: [
    ...DEMO_DIRECTIVES,
    ToastrOverviewComponent,
    PinkToast,
    NotyfToast
  ],
  entryComponents: [...DEMO_DIRECTIVES, PinkToast, NotyfToast]
})
export class ToastrDocModule {
  constructor(demoList: NgbdDemoList) {
    demoList.register("toastr", DEMOS, OVERVIEW);
  }
}
