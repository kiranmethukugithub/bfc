import { NgModule } from '@angular/core';

import { ComponentWrapperComponent, DocumentationSharedModule, NgbdDemoList, NgbdExamplesPage, NgbdDemoListConfig } from '../../shared';
import { NgbdDropdownBasic } from './demos/basic/dropdown-basic';
import { NgbdDropdownConfig } from './demos/config/dropdown-config';
import { NgbdDropdownManual } from './demos/manual/dropdown-manual';
import { NgbdDropdownSplit } from './demos/split/dropdown-split';
import { SharedModule } from 'app/shared';

const DEMO_DIRECTIVES = [
  NgbdDropdownBasic,
  NgbdDropdownConfig,
  NgbdDropdownManual,
  NgbdDropdownSplit
];

const DEMOS: NgbdDemoListConfig = {
  basic: {
    title: 'Dropdown',
    type: NgbdDropdownBasic,
    code: require('!!raw-loader!./demos/basic/dropdown-basic'),
    markup: require('!!raw-loader!./demos/basic/dropdown-basic.html')
  },
  manual: {
    title: 'Manual and custom triggers',
    type: NgbdDropdownManual,
    code: require('!!raw-loader!./demos/manual/dropdown-manual'),
    markup: require('!!raw-loader!./demos/manual/dropdown-manual.html')
  },
  split: {
    title: 'Button groups and split buttons',
    type: NgbdDropdownSplit,
    code: require('!!raw-loader!./demos/split/dropdown-split'),
    markup: require('!!raw-loader!./demos/split/dropdown-split.html')
  },
  config: {
    title: 'Global configuration of dropdowns',
    type: NgbdDropdownConfig,
    code: require('!!raw-loader!./demos/config/dropdown-config'),
    markup: require('!!raw-loader!./demos/config/dropdown-config.html')
  }
};

export const DROPDOWN_ROUTES = [
  { path: '', pathMatch: 'full', redirectTo: 'examples' },
  {
    path: '',
    component: ComponentWrapperComponent,
    children: [
      { path: 'examples', component: NgbdExamplesPage },
      // { path: 'api', component: NgbdApiPage }
    ]
  }
];

@NgModule({
  imports: [
    SharedModule,
    DocumentationSharedModule
  ],
  declarations: DEMO_DIRECTIVES,
  entryComponents: DEMO_DIRECTIVES
})
export class DropdownDocModule {
  constructor(demoList: NgbdDemoList) {
    demoList.register('dropdown', DEMOS);
  }
}
