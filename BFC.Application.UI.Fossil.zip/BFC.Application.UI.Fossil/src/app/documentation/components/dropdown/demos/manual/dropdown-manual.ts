import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-dropdown-manual',
  templateUrl: './dropdown-manual.html'
})
export class NgbdDropdownManual {
}
