import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tabset-orientation',
  templateUrl: './tabset-orientation.html'
})
export class NgbdTabsetOrientation {
  currentOrientation = 'horizontal';
}
