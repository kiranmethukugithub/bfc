import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tabset-selectbyid',
  templateUrl: './tabset-selectbyid.html'
})
export class NgbdTabsetSelectbyid {
}
