import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-rating-basic',
  templateUrl: './rating-basic.html'
})
export class NgbdRatingBasic {
  currentRate = 8;
}
