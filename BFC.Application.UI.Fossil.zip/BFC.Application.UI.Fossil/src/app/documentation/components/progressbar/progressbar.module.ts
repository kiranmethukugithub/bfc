import { NgModule } from '@angular/core';

import { ComponentWrapperComponent, DocumentationSharedModule, NgbdDemoList, NgbdExamplesPage, NgbdDemoListConfig } from '../../shared';
import { NgbdProgressbarBasic } from './demos/basic/progressbar-basic';
import { NgbdProgressbarConfig } from './demos/config/progressbar-config';
import { NgbdProgressbarHeight } from './demos/height/progressbar-height';
import { NgbdProgressbarLabels } from './demos/labels/progressbar-labels';
import { NgbdProgressbarShowvalue } from './demos/showvalue/progressbar-showvalue';
import { NgbdProgressbarStriped } from './demos/striped/progressbar-striped';
import { SharedModule } from 'app/shared';

const DEMO_DIRECTIVES = [
  NgbdProgressbarBasic,
  NgbdProgressbarShowvalue,
  NgbdProgressbarStriped,
  NgbdProgressbarConfig,
  NgbdProgressbarLabels,
  NgbdProgressbarHeight
];

const DEMOS: NgbdDemoListConfig = {
  basic: {
    title: 'Contextual progress bars',
    type: NgbdProgressbarBasic,
    code: require('!!raw-loader!./demos/basic/progressbar-basic'),
    markup: require('!!raw-loader!./demos/basic/progressbar-basic.html')
  },
  showvalue: {
    title: 'Progress bars with current value labels',
    type: NgbdProgressbarShowvalue,
    code: require('!!raw-loader!./demos/showvalue/progressbar-showvalue'),
    markup: require('!!raw-loader!./demos/showvalue/progressbar-showvalue.html')
  },
  striped: {
    title: 'Striped progress bars',
    type: NgbdProgressbarStriped,
    code: require('!!raw-loader!./demos/striped/progressbar-striped'),
    markup: require('!!raw-loader!./demos/striped/progressbar-striped.html')
  },
  labels: {
    title: 'Progress bars with custom labels',
    type: NgbdProgressbarLabels,
    code: require('!!raw-loader!./demos/labels/progressbar-labels'),
    markup: require('!!raw-loader!./demos/labels/progressbar-labels.html')
  },
  height: {
    title: 'Progress bars with height',
    type: NgbdProgressbarHeight,
    code: require('!!raw-loader!./demos/height/progressbar-height'),
    markup: require('!!raw-loader!./demos/height/progressbar-height.html')
  },
  config: {
    title: 'Global configuration of progress bars',
    type: NgbdProgressbarConfig,
    code: require('!!raw-loader!./demos/config/progressbar-config'),
    markup: require('!!raw-loader!./demos/config/progressbar-config.html')
  }
};

export const PROGRESSBAR_ROUTES = [
  { path: '', pathMatch: 'full', redirectTo: 'examples' },
  {
    path: '',
    component: ComponentWrapperComponent,
    children: [
      { path: 'examples', component: NgbdExamplesPage },
    ]
  }
];

@NgModule({
  imports: [
    SharedModule,
    DocumentationSharedModule
  ],
  declarations: DEMO_DIRECTIVES,
  entryComponents: DEMO_DIRECTIVES
})
export class ProgressbarDocModule {
  constructor(demoList: NgbdDemoList) {
    demoList.register('progressbar', DEMOS);
  }
}
