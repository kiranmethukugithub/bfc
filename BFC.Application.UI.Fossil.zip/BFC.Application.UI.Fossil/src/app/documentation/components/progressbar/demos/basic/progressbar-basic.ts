import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-progressbar-basic',
  templateUrl: './progressbar-basic.html',
  styles: [`
    ngb-progressbar {
      margin-top: 5rem;
    }
  `]
})
export class NgbdProgressbarBasic {
}
