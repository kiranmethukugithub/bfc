import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-buttons-radio',
  templateUrl: './buttons-radio.html'
})
export class NgbdButtonsRadio {
  model = 1;
}
