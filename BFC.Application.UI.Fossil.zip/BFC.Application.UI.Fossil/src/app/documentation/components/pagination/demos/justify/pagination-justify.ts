import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-pagination-justify',
  templateUrl: './pagination-justify.html'
})
export class NgbdPaginationJustify {
  page = 4;
}
