import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-pagination-basic',
  templateUrl: './pagination-basic.html'
})
export class NgbdPaginationBasic {
  page = 4;
}
