import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-pagination-size',
  templateUrl: './pagination-size.html'
})
export class NgbdPaginationSize {
  currentPage = 3;
}
