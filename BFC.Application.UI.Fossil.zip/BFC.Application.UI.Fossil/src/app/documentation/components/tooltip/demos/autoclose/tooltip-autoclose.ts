import {Component} from '@angular/core';



@Component({
  selector: 'ngbd-tooltip-autoclose',
  templateUrl: './tooltip-autoclose.html'
})
export class NgbdTooltipAutoclose {}
