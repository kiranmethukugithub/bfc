import {Component} from '@angular/core';

@Component({
  selector: 'ngbd-tooltip-triggers',
  templateUrl: './tooltip-triggers.html'
})
export class NgbdTooltipTriggers {
}
