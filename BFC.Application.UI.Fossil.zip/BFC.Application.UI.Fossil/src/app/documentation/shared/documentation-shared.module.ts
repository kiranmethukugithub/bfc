
import { NgModule } from '@angular/core';

import { NgbdWidgetDemoComponent } from './examples-page/demo.component';
import { NgbdExamplesPage } from './examples-page/examples.component';
import { NgbdFragment } from './fragment';
import { NgbdOverviewDirective, NgbdOverviewSectionComponent } from './overview';
import { PageWrapperComponent } from './page-wrapper/page-wrapper.component';
import { ComponentWrapperComponent } from './component-wrapper/component-wrapper.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
// import { BrowserModule } from '@angular/platform-browser';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from 'app/shared';

@NgModule({
  imports: [
    NgbModule,
    RouterModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule, // TODO Consider this dependency?
  ],
  declarations: [
    NgbdFragment,
    NgbdOverviewDirective,
    NgbdOverviewSectionComponent,
    NgbdExamplesPage,
    NgbdWidgetDemoComponent,
    PageWrapperComponent,
    ComponentWrapperComponent
  ],
  exports: [
    CommonModule,
    NgbModule,
    NgbdFragment,
    NgbdOverviewDirective,
    NgbdOverviewSectionComponent,
    NgbdExamplesPage,
    NgbdWidgetDemoComponent,
    PageWrapperComponent,
    ComponentWrapperComponent
  ]
})
export class DocumentationSharedModule {}
