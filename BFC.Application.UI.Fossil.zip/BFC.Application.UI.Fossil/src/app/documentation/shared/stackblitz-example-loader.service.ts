import sdk from '@stackblitz/sdk';

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Project } from '@stackblitz/sdk/typings/interfaces';

// Create the index.ts file
const code = `import moment from 'moment';

document.getElementById('time').innerHTML = moment().format('MMMM Do YYYY, h:mm:ss a');
`;

// Create the index.html file
const html = `<h1>I was created on <span id='time'></span></h1>`;

// Create the project payload.
const defaultProject = {
  files: {
    'index.ts': code,
    'index.html': html
  },
  title: 'Dynamically Generated Project',
  description: 'Created with <3 by the StackBlitz SDK!',
  template: 'typescript',
  tags: ['stackblitz', 'sdk'],
  dependencies: {
    moment: '*' // * = latest version
  }
};

@Injectable()
export class StackblitzExampleLoaderService {
  constructor(private http: HttpClient) { }

  openProject(project: Project = defaultProject) {
    sdk.openProject(project);
  }

  // TODO Embedding with a component maybe??
}
