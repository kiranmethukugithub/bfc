import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { StackblitzExampleLoaderService } from '../stackblitz-example-loader.service';

@Component({
  selector: 'ngbd-widget-demo',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './demo.component.html'
})
export class NgbdWidgetDemoComponent {
  @Input() demoTitle: string;
  @Input() component: string;
  @Input() id: string;
  @Input() code: string;
  @Input() markup: string;

  constructor(private stackblitzService: StackblitzExampleLoaderService) { }

  openInStackBlitz() {
    this.stackblitzService.openProject();
  }
}
