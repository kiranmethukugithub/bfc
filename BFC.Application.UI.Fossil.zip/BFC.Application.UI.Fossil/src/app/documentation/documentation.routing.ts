import { Routes } from '@angular/router';
import {
  ACCORDION_ROUTES,
  ALERT_ROUTES,
  BUTTONS_ROUTES,
  CAROUSEL_ROUTES,
  COLLAPSE_ROUTES,
  DATEPICKER_ROUTES,
  DROPDOWN_ROUTES,
  FONTAWESOME_ROUTES,
  MODAL_ROUTES,
  PAGINATION_ROUTES,
  POPOVER_ROUTES,
  PROGRESSBAR_ROUTES,
  RATING_ROUTES,
  TABLE_ROUTES,
  TABSET_ROUTES,
  TIMEPICKER_ROUTES,
  TOOLTIP_ROUTES,
  TYPEAHEAD_ROUTES,
  IDLE_ROUTES,
  TOASTR_ROUTES
} from './components';

export const DocRoutes: Routes = [
  {
    path: 'accordion',
    children: ACCORDION_ROUTES
  },
  {
    path: 'alert',
    children: ALERT_ROUTES
  },
  {
    path: 'buttons',
    children: BUTTONS_ROUTES
  },
  {
    path: 'carousel',
    children: CAROUSEL_ROUTES
  },
  {
    path: 'collapse',
    children: COLLAPSE_ROUTES
  },
  {
    path: 'datepicker',
    children: DATEPICKER_ROUTES
  },
  {
    path: 'dropdown',
    children: DROPDOWN_ROUTES
  },
  {
    path: 'font-awesome',
    children: FONTAWESOME_ROUTES
  },
  {
    path: 'modal',
    children: MODAL_ROUTES
  },
  {
    path: 'pagination',
    children: PAGINATION_ROUTES
  },
  {
    path: 'popover',
    children: POPOVER_ROUTES
  },
  {
    path: 'progressbar',
    children: PROGRESSBAR_ROUTES
  },
  {
    path: 'rating',
    children: RATING_ROUTES
  },
  {
    path: 'table',
    children: TABLE_ROUTES
  },
  {
    path: 'tabset',
    children: TABSET_ROUTES
  },
  {
    path: 'timepicker',
    children: TIMEPICKER_ROUTES
  },
  {
    path: 'tooltip',
    children: TOOLTIP_ROUTES
  },
  {
    path: 'typeahead',
    children: TYPEAHEAD_ROUTES
  },
  {
    path: 'idle',
    children: IDLE_ROUTES
  },
  {
    path: 'toastr',
    children: TOASTR_ROUTES
  },
  {
    path: '**',
    redirectTo: 'accordion'
  }
];
