import { Component, Input } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-idle-logout',
  templateUrl: './idle-logout.component.html'
})
export class IdleLogoutComponent {

  constructor(public activeModal: NgbActiveModal) { }
}
