import { Component, OnInit, ElementRef, ViewChild, Input } from '@angular/core';
import { Router, NavigationStart, RouterLink } from '@angular/router';
import {
    ConfigService,
    Logger,
    // SessionService,
    // UserSessionModel,
    globalAnimations,
    AppConfig,
    // UsersAndProfilesService,
    // CompanyConfigurationService,
} from 'app/shared';
import { Observable } from 'rxjs';

// 3rd Party Dependencies
import { OAuthService } from 'angular-oauth2-oidc';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss'],
    animations: [...globalAnimations]
})
export class HeaderComponent implements OnInit {
    megaMenuOpen: boolean;
    // userSessionModel: UserSessionModel;
    appConfig: AppConfig;

    constructor(
        private configService: ConfigService,
        private router: Router,
        private oauthService: OAuthService,
        // private session: SessionService,
        // private usersAndProfileService: UsersAndProfilesService,
        // private companyConfigurationService: CompanyConfigurationService
    ) { }

    ngOnInit(): void {
        this.appConfig = this.configService.getConfig();
        // this.userSessionModel = this.session.GetUserSession();

        this.configService.onConfigChanged.subscribe(newConfig => {
            this.appConfig = newConfig;
        });

        // this.session.onSessionChanged.subscribe(newSession => {
        //     if (newSession == null) { return; } // TODO Fix this to not produce nulls.
        //     this.userSessionModel = newSession;
        // });
    }



    onMegaMenuLinkClicked() {
        this.megaMenuOpen = false;
    }
    toggleMegaMenu() {
        this.megaMenuOpen = !this.megaMenuOpen;
    }

    public logOut(): any {
        // Close counter
        // if (this.userSessionModel.counterCode) {
        //     this.companyConfigurationService.closeCounter(this.userSessionModel.counterCode).catch(error => {
        //         this.clearSessionAndRedirect();
        //         return Observable.throw(error);
        //     }).subscribe(() => {
        //         this.clearSessionAndRedirect();
        //     });
        // } else {
        //     this.clearSessionAndRedirect();
        // }
    }

    private clearSessionAndRedirect() {
        // Then clear serverside session.
        // this.usersAndProfileService
        // .clearUserSessionByUsername(this.userSessionModel.username)
        // .catch(error => {
        //     this.session.Clear(); // TODO ????
        //     return Observable.throw(error);
        // })
        // .subscribe(data => {
        //     const relativeReirectUrl = new URL(this.appConfig.auth.logoutUrl).pathname;
        //     console.log(relativeReirectUrl);

        //     this.oauthService.logOut(true);

        //     // https://github.com/manfredsteyer/angular-oauth2-oidc/issues/263
        //     // This is a fix as the oAuthLibrary isnt redirecting.
        //     this.router.navigateByUrl(relativeReirectUrl);
        //     this.session.Clear(); // TODO??
        // });
    }
}
