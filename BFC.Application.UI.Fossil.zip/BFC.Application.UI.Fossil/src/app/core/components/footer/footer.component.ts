﻿import { Component, OnInit } from '@angular/core';
import { ConfigService } from 'app/shared';

@Component({
    selector: 'app-footer',
    templateUrl: './footer.component.html',
    styleUrls: ['./footer.component.scss']
})

export class FooterComponent implements OnInit {

    version: string;

    // userSessionModel: UserSessionModel;

    businessDate: Date;

    transactionDate: Date;

    constructor(private configService: ConfigService
      // ,private session: SessionService
      ) {}

    ngOnInit(): void {
      this.version = this.configService.getConfig().version;

        // this.userSessionModel = this.session.GetObjectByKey('UserSessionModel');
        // this.transactionDate = new Date();

        // if (this.userSessionModel !== null) {
        //     this.businessDate = this.userSessionModel.businessDate;
        // }
    }

}
