import { Component, OnInit, AfterViewInit, AfterContentInit, ViewEncapsulation } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'environments/environment';
import { Logger } from 'app/shared';


@Component({
    selector: 'app-side-nav',
    templateUrl: './side-nav.component.html',
    styleUrls: ['./side-nav.component.scss'],
    encapsulation: ViewEncapsulation.None // TODO Consider the CSS Here and move it as needed
})
export class SideNavComponent implements OnInit {
    open: boolean;
    private modal: NgbModalRef;
    // menuData: TransactionPendingQueueMenu[];

    constructor(
        private modalService: NgbModal,
        private router: Router,
        private log: Logger,
        // private transactionPendingQueueService: TransactionPendingQueueService
    ) {
    }

    ngOnInit() {

        // TOD Consider making this a configurable time span.
        // Observable.timer(0, 60000).subscribe(_ => {
        //     this.loadPendingMenus();
        // });

        // this.transactionPendingQueueService.onRefreshQueue.subscribe(_ => {
        //     this.loadMenus();
        // });

        // this.loadMenus();
    }

    loadMenus() {
        // this.transactionPendingQueueService.GetTransactionsMenu().subscribe(
        //     menuData => {
        //         this.menuData = menuData;
        //     }
        // );
    }

    lookupCurrencies() {
        // this.modal = this.modalService.open(CurrencyLookupComponent, { size: 'lg', windowClass: 'modal-center' });
    }

    lookupSwiftCodes() {
        // this.modal = this.modalService.open(SwiftCodeLookupComponent, { size: 'lg', windowClass: 'modal-center' });
    }

    lookupLiaisons() {
        // this.modal = this.modalService.open(LiaisonLookupComponent, { size: 'lg', windowClass: 'modal-center' });
    }

    lookupBanks() {
        // this.modal = this.modalService.open(BanksLookupComponent, { size: 'lg', windowClass: 'modal-center' });
    }

    lookupRates() {
        // this.router.navigate(['/rate-sheets']);
        // this.modal = this.modalService.open(RateSheetLookupComponent, { size: 'lg', windowClass: 'modal-center' });
    }
    refreshQueue() {
        // this.loadMenus();
    }

    viewPending(transactionType: string) {
        // this.router.navigate(['/transaction-pending-queue/pending-authorisation/' + transactionType]);
    }

    viewAwaiitingProcessing(transactionType: string) {
        // this.router.navigate(['/transaction-pending-queue/pending-processing/' + transactionType]);
    }
    viewChecking(transactionType: string) {
        // this.router.navigate(['/transaction-pending-queue/pending-checking/' + transactionType]);
    }
}
