﻿import { Component, Output, EventEmitter, Input } from '@angular/core';
import {
    // UserPermissionService,
    globalAnimations
} from 'app/shared';

@Component({
    selector: 'app-mega-menu',
    templateUrl: './mega-menu.component.html',
    styleUrls: ['./mega-menu.component.scss'],
    animations: [
        ...globalAnimations
    ]
})
export class MegaMenuComponent {

    @Input() open: boolean;

    // TODO
    // tslint:disable-next-line:no-output-on-prefix
    @Output() public onLinkClicked = new EventEmitter();
    constructor(
        // protected userPermissionService: UserPermissionService
        ) {  }

    linkedClicked() {
        this.onLinkClicked.emit();
    }
}
