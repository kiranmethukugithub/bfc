import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-error-404',
    templateUrl: './error-404.component.html',
    styleUrls: ['./error-404.component.scss']
})
export class Error404Component {
    invalidUrl;

    constructor(public router: Router) {
        if (router.url !== '/error/404') {
            this.invalidUrl = router.url;
        }
    }
}
