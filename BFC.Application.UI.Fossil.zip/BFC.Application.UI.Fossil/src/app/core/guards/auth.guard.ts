import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, Router, CanActivate, CanActivateChild } from '@angular/router';
import { Observable } from 'rxjs';

import {
  Logger,
  LogLevel,
  ConfigService,
  SplashScreenService
} from '../../shared';
import { OAuthService, JwksValidationHandler, OAuthEvent } from 'angular-oauth2-oidc';

@Injectable()
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(
    private oauthService: OAuthService,
    private log: Logger,
  ) {
    this.log.write(LogLevel.Trace, 'AuthGuard Constructed');
  }

  canActivateChild(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.canActivate(next, state);
  }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> {
    // this.splashScreenService.displayMessage('Verifying login information...', 'status');
    this.log.write(LogLevel.Trace, 'AuthGuard Processing canActive status');

    return new Promise<boolean>((resolve, reject) => {

      this.log.write(LogLevel.Trace, `User has valid IdToken: ${this.oauthService.hasValidIdToken()}`);
      this.log.write(LogLevel.Trace, `User has valid AccessToken: ${this.oauthService.hasValidAccessToken()}`);

      if (this.oauthService.hasValidAccessToken() && this.oauthService.hasValidIdToken()) {
        this.log.writeData(LogLevel.Debug, 'User has valid authentication data.');
        resolve(true);
      } else {

        this.log.write(LogLevel.Debug, 'Loading Identity Discovery Document and Attempting to Login');

        this.oauthService
          .loadDiscoveryDocumentAndTryLogin()
          .then(_ => this.oauthService.hasValidIdToken() && this.oauthService.hasValidAccessToken())
          .then(isAuthenticated => {
            if (!isAuthenticated) {
              // this.splashScreenService.displayMessage(
              //     'You are being redirected to your organisations login provider...',
              //     'status'
              // );
              this.log.write(LogLevel.Debug, `Redirecting to Identity server with redirect URL: ${state.url}`);

              this.oauthService.initImplicitFlow(state.url);
              // resolve(false); // TODO check if needed.
            } else {
              // TODO Get User Profile or something like that...
            }

            this.log.write(LogLevel.Debug, 'User has been authenticated against the identity server.');

            resolve(isAuthenticated);
          });
      }
    });
  }
}
