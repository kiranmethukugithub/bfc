import { ErrorHandler, Injectable, Injector } from '@angular/core';
import swal from 'sweetalert2';
import { HttpErrorResponse } from '@angular/common/http';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
    errorMessage = 'An error occured:';
    validationMessage = 'Validation failed';

    constructor(private injector: Injector) { }

    handleError(error: Error | HttpErrorResponse) {
        if (error instanceof HttpErrorResponse) {
            swal('An Http Error occured. Please contact the system administrator.');
        } else if (error instanceof Error) {
            swal('An JavaScript error occured. Please contact the system administrator.');
        } else {
            swal('An unknown error occured. Please contact the system administrator.');
        }

        console.error(error);
    }
}
