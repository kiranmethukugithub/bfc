﻿import { Component, OnInit, AfterViewInit, AfterContentInit } from '@angular/core';
import {
    Logger,
    // PinManagementModalComponent,
    LogLevel,
    ElementScrollUtils,
    // SessionService,
    // UserSessionModel,
    // UsersAndProfilesService
} from 'app/shared';
// import { Observable } from 'rxjs/Observable';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router, RouterEvent, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';
import { fromEvent } from 'rxjs';
import { environment } from 'environments/environment';

@Component({
    selector: 'app-main-layout',
    templateUrl: './main-layout.component.html',
    styleUrls: ['./main-layout.component.scss']
})
export class MainLayoutComponent implements OnInit {
    modal: NgbModalRef;

    developmentMode: boolean;
    routeLoading = false;
    // userSession: UserSessionModel;

    constructor(
        private modalService: NgbModal,
        private log: Logger,
        private router: Router,
        // private session: SessionService,
        // private usersAndProfilesService: UsersAndProfilesService
    ) {
        this.developmentMode = !environment.production;
        // this.userSession = this.session.GetUserSession();
        // this.checkUserPinExpiration();
    }

    ngOnInit() {
        this.log.write(LogLevel.Trace, 'MainLayout OnInit');

        this.setupRouterLoadingEvents();
    }

    private setupRouterLoadingEvents() {
        this.router.events.subscribe((event: RouterEvent) => {
            switch (true) {
                case event instanceof NavigationStart: {
                    this.routeLoading = true;
                    break;
                }

                case event instanceof NavigationEnd:
                case event instanceof NavigationCancel:
                case event instanceof NavigationError: {
                    this.routeLoading = false;
                    break;
                }
                default: {
                    break;
                }
            }
        });
    }

    // private checkUserPinExpiration() {
    //     const requiresAuthorisationPin = this.userSession.authorizeProfiles
    //         ? this.userSession.authorizeProfiles.some(x => x.requiresAuthorisationPin === true)
    //         : false;

    //     if (requiresAuthorisationPin) {
    //         this.usersAndProfilesService.getUserPinExpiryInfo(this.userSession.username).subscribe(pinExpiryInfo => {
    //             if (pinExpiryInfo.isPinSet) {
    //                 if (pinExpiryInfo.isPinExpired) {
    //                     this.loadExpiredPinModal();
    //                 }
    //             } else {
    //                 this.loadNewPinModal();
    //             }
    //         });
    //     }
    // }

    // loadNewPinModal() {
    //     this.modal = this.modalService.open(PinManagementModalComponent, { size: 'sm', windowClass: 'modal-center', backdrop: false });
    //     this.modal.componentInstance.isEditMode = false;
    //     this.modal.result.then(result => { }).catch(error => { });
    // }

    // loadExpiredPinModal() {
    //     this.modal = this.modalService.open(PinManagementModalComponent, { size: 'sm', windowClass: 'modal-center', backdrop: false });
    //     this.modal.componentInstance.isEditMode = true;
    //     this.modal.result.then(result => { }).catch(error => { });
    // }
}
