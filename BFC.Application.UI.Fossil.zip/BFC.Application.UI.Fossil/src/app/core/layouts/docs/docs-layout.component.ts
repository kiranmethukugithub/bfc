﻿import { Component, ElementRef, OnInit } from '@angular/core';
import {
    Logger,
    LogLevel,
} from 'app/shared';
import { NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router, RouterEvent, NavigationStart, NavigationEnd, NavigationCancel, NavigationError } from '@angular/router';

export const componentsList = [
    'Accordion', 'Alert', 'Buttons', 'Carousel', 'Collapse', 'Datepicker', 'Dropdown', 'Font-awesome', 'Modal', 'Pagination', 'Popover',
    'Progressbar', 'Rating', 'Table', 'Tabset', 'Timepicker', 'Tooltip', 'Typeahead'
];

export const serviceList = [
    'Toastr',
    'Idle'
];

@Component({
    selector: 'app-docs-layout',
    templateUrl: './docs-layout.component.html',
    styleUrls: ['./docs-layout.component.scss']
})
export class DocsLayoutComponent implements OnInit {
    modal: NgbModalRef;

    components = componentsList;
    services = serviceList;

    routeLoading = false;

    constructor(
        private log: Logger,
        private router: Router,
    ) { }

    isActive(currentRoute: any[], exact = true): boolean {
        const treeUrl = this.router.createUrlTree(currentRoute);
        return this.router.isActive(treeUrl, exact);
    }

    ngOnInit() {
        this.log.write(LogLevel.Trace, 'DocsLayout OnInit');

        this.setupRouterLoadingEvents();
    }

    private setupRouterLoadingEvents() {
        this.router.events.subscribe((event: RouterEvent) => {
            switch (true) {
                case event instanceof NavigationStart: {
                    this.routeLoading = true;
                    break;
                }

                case event instanceof NavigationEnd:
                case event instanceof NavigationCancel:
                case event instanceof NavigationError: {
                    this.routeLoading = false;
                    break;
                }
                default: {
                    break;
                }
            }
        });
    }
}
