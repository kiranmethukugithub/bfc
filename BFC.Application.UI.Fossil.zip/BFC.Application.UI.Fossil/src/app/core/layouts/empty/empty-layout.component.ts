﻿import { Component } from '@angular/core';

@Component({
  selector: 'app-empty-layout',
  template: '<router-outlet></router-outlet>'
})
export class EmptyLayoutComponent {

}
