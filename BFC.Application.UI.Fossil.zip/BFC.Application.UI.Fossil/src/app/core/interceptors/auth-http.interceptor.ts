import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { OAuthService } from 'angular-oauth2-oidc';
import { ActiveXService } from 'app/shared';

@Injectable()
export class AuthHttpInterceptor implements HttpInterceptor {
    constructor(private oAuthService: OAuthService, private activeXService: ActiveXService) { }
    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        const token = this.oAuthService.getAccessToken();

        let clonedRequest = request.clone({
            withCredentials: true
        });

        if (!request.headers.has('Access-Control-Allow-Origin')) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    'Access-Control-Allow-Origin': 'true'
                }
            });
        }

        if (token) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    Authorization: `Bearer ${token}`
                }
            });
        }

        if (!request.headers.has('Content-Type')) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    'Content-Type': `application/json`
                }
            });
        }

        if (!request.headers.has('Accept')) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    Accept: `application/json`
                }
            });
        }

        if (!request.headers.has('Cache-Control')) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    'Cache-Control': 'no-cache'
                }
            });
        }

        if (!request.headers.has('Pragma')) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    Pragma: 'no-cache'
                }
            });
        }

        const macAddress = this.activeXService.getMACAddress();
        if (!request.headers.has('MAC-Address')) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    'MAC-Address': macAddress || ''
                }
            });
        }

        const ipAddress = this.activeXService.getIPAddress();
        if (!request.headers.has('IP-Address')) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    'IP-Address': ipAddress || ''
                }
            });
        }

        const machineName = this.activeXService.getMachineName();
        if (!request.headers.has('Machine-Name')) {
            clonedRequest = clonedRequest.clone({
                setHeaders: {
                    'Machine-Name': machineName || ''
                }
            });
        }

        return next.handle(clonedRequest);
    }
}
