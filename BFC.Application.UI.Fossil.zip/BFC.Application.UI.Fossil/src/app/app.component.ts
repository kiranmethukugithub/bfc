import { Component, OnInit } from '@angular/core';
import { SplashScreenService, Logger, LogLevel, ConfigService, ElementScrollUtils } from './shared';
import { UserIdleService } from './modules/user-idle';
import { ToastrService } from 'ngx-toastr';
import { Router, Scroll } from '@angular/router';
import { fromEvent } from 'rxjs';
import { filter, first } from 'rxjs/operators';
import { OAuthService, OAuthEvent, JwksValidationHandler } from 'angular-oauth2-oidc';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IdleLogoutComponent } from './core/components/idle-logout/idle-logout.component';

declare let device: any;

const SideNavElementId = 'SideNav';
const FooterBarElementId = 'Footer';
const HeaderElementId = 'HeaderBar';
const ActionBarElementId = 'ActionBar';
const DefaultScrollbarSize = 17;

// @Component({
//   selector: 'ngbd-modal-component',
//   templateUrl: './modal-component.html'
// })
// export class NgbdModalComponent {
//   constructor(private modalService: NgbModal) {}

//   open() {
//     const modalRef = this.modalService.open(NgbdModalContent);
//     modalRef.componentInstance.name = 'World';
//   }
// }

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  silentRefreshInProgress = false;
  /**
   * @param splashScreenService The splash screen service.
   */
  constructor(
    private splashScreenService: SplashScreenService,
    private userIdle: UserIdleService,
    private configService: ConfigService,
    private toastrService: ToastrService,
    private router: Router,
    private log: Logger,
    private oAuthService: OAuthService,
    private modalService: NgbModal) {

    splashScreenService.init();
    this.setupAuth();
  }

  ngOnInit(): void {
    document.addEventListener('deviceready', function () {
      alert(device.platform);
    }, false);

    fromEvent(window, 'resize').subscribe((event: any) => {
      this.fixSideBarPadding();
    });

    fromEvent(window, 'onload').subscribe((event: any) => {
      this.fixSideBarPadding();
    });

    this.setupIdleService(); // TODO Move somewhere it wont trigger if Identity fails...
    this.setupFramgemtScroll();
  }

  private setupFramgemtScroll() {
    this.router.events
      .pipe(filter(event => event instanceof Scroll))
      .subscribe(event => {
        const { fragment } = this.router.parseUrl(this.router.url);
        if (fragment) {
          setTimeout(() => {
            const element = document.querySelector(`#${fragment}`);
            if (element) {
              element.scrollIntoView();
            }
          }, 0);
        } else {
          const element = document.querySelector(`#top`);
          if (element) {
            element.scrollIntoView();
          }
          // this.viewportScroller.scrollToPosition([0, 0]);
          // window.scrollTo({ top: 0 });
        }
      });
  }

  private setupAuth() {
    this.log.write(LogLevel.Debug, 'Configuraing Authentication');
    this.oAuthService.configure(this.configService.getConfig().auth);
    this.oAuthService.tokenValidationHandler = new JwksValidationHandler();
    this.oAuthService.setupAutomaticSilentRefresh();

    // TODO Test moving this to app.component.ts
    this.oAuthService.events.subscribe(({ type }: OAuthEvent) => {
      this.log.write(LogLevel.Trace, 'oAuthEvent Occured: ' + type);
      console.log('oAuthEvent Occured: ' + type);
      switch (type) {
        case 'token_received': {
          this.log.write(LogLevel.Trace, `Recieved Previous Location in State: ${this.oAuthService.state}`);

          // This causes angular to load twice... so it doesnt solve the issue below
          // window.location.href = this.oauthService.state;

          // This doesnt cause the router to navigate because the oauth/oidc lib is still
          // processing something and tries to implicitly navigate to root / from what i can tell.
          // this.router.navigateByUrl(this.oauthService.state);

          // Delay long enough for the OIDC library to finsh what its doing.
          // Before Navigating to the previous route.
          // https://github.com/manfredsteyer/angular-oauth2-oidc/issues/220#issuecomment-379744721
          if (!this.silentRefreshInProgress) {
            setTimeout(() => {
              this.router.navigate([this.oAuthService.state]); /// Starting URL...
            }, 16);
          }

          break;
        }

        case 'token_expires': {
          this.silentRefreshInProgress = true;
          break;
        }

        case 'token_received': {
          break;
        }

        case 'silently_refreshed': {
          this.silentRefreshInProgress = false;
          break;
        }

        case 'discovery_document_load_error': {
          this.splashScreenService.hideSpinner();
          this.splashScreenService.setStatus('Unable to contact the Identity server.', 'error');
          break;
        }
      }
    });
  }

  private setupIdleService() {
    const idleConfig = this.configService.getConfig().userIdle;

    if (idleConfig && idleConfig.enabled) {
      this.userIdle.setConfigValues({ idle: idleConfig.idle, timeout: idleConfig.timeout, ping: idleConfig.warningInterval });

      // Start watching for user inactivity.
      this.userIdle.startWatching();

      // Start watching when user idle is starting.
      this.userIdle.onTimerStart().pipe(first(count => count === 1)).subscribe(() => {
        this.openIdleNotice();
      });

      // this.userIdle.onTimerStart().subscribe(count => );

      // this.userIdle.onPing().subscribe(pingNumber => this.toastrService.warning('You are about to timeout due to inactivity.'));

      // Start watch when time is up.
      this.userIdle.onTimeout().subscribe(() => this.toastrService.error('You timedout!'));
    }
  }

  private fixSideBarPadding() {
    this.log.write(LogLevel.Debug, 'Fixing sidebar padding...');
    setTimeout(() => {
      const headerSize = document.getElementById(HeaderElementId).offsetHeight;
      const sideNavElement: any = document.getElementById(SideNavElementId);
      const footerHeight = document.getElementById(FooterBarElementId).offsetHeight;
      const actionBarElement = document.getElementById(ActionBarElementId);

      const actionBarSize = actionBarElement ? actionBarElement.offsetHeight : 0; // TODO Not working on document load

      const adjustmentSize =
        (ElementScrollUtils.hasHorizontalScroll() ?
          footerHeight + DefaultScrollbarSize : footerHeight) + headerSize + actionBarSize;

      sideNavElement.style.height = `calc(100vh - ${adjustmentSize}px)`;
    }, 1);
  }

  private openIdleNotice() {
    this.toastrService.warning('You are about to timeout due to inactivity.');
    const modalRef = this.modalService.open(IdleLogoutComponent);
    // modalRef.componentInstance.name = 'World';
  }
}
