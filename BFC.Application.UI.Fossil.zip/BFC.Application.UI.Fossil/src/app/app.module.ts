// Angular
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, ErrorHandler } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER } from '@angular/core';

// 3rd Party
import {
  NgbDateAdapter,
  NgbDateParserFormatter
} from '@ng-bootstrap/ng-bootstrap';
import { ToastrModule } from 'ngx-toastr';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { TranslateService } from '@ngx-translate/core';
import { TranslateModule } from '@ngx-translate/core';
import { OAuthModule, OAuthService } from 'angular-oauth2-oidc';

// Core Components
import { AppComponent } from './app.component';
import { AppRoutes } from './app.routing';

import {
  // AuthGuard,
  SideNavComponent,
  FooterComponent,
  EmptyLayoutComponent,
  MainLayoutComponent,
  DocsLayoutComponent,
  HeaderComponent,
  AuthHttpInterceptor,
  Error401Component,
  Error404Component,
  Error500Component,
  Error503Component,
  MegaMenuComponent,
  IdleLogoutComponent
} from 'app/core';

// Shared Modules
import {
  SharedModule,
  ConfigService,
  Logger,
  ConsoleLogger,
  // AutoLogoutService, TODO
  NgbNativeDateAdapter,
  // NgbTimeStringAdapter,
  NgbDateFormatter,
  TranslationLoaderService,
  ActiveXService
} from 'app/shared';

// Configuration Functions For Global Modules
import { appInitializer, originFactory } from './app.startup';
import { AuthGuard } from './core/guards/auth.guard';
import { UserIdleModule } from './modules/user-idle/user-idle.module';
import { GlobalErrorHandler } from './core/services/global-error-handler.service';
import { DelayComponentLoadingResolver } from './shared/resolvers/delay-component-loading.resolver';

// Demos TODO Remove for lazy load
// import { NgbdAccordionModule } from './samples/components/accordion/accordion.module';
// import { IconsSampleModule } from './samples/components/icons/icons.module';

// const DEMOS = [
//   NgbdAccordionModule,
//   IconsSampleModule
// ];

// Module Definition
@NgModule({
  declarations: [
    /* Core Componments */
    AppComponent,
    MainLayoutComponent,
    DocsLayoutComponent,
    EmptyLayoutComponent,
    HeaderComponent,
    SideNavComponent,
    FooterComponent,
    MegaMenuComponent,
    Error401Component, // TODO Consider Condensing these into one component?
    Error404Component,
    Error500Component,
    Error503Component,
    IdleLogoutComponent

    /* Feature Components */ // TODO This will be removed once you enable lazy loading??
    // ChatComponent
  ],
  imports: [
    /* Angular Modules */
    CommonModule,
    FormsModule,
    HttpClientModule,
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(AppRoutes, {
      anchorScrolling: 'enabled',
      scrollPositionRestoration: 'enabled'
    }),

    /* App Modules */
    SharedModule.forRoot(),
    UserIdleModule.forRoot(),

    /* 3rd Party Modules */
    ToastrModule.forRoot(),
    NgbModule,
    TranslateModule.forRoot(),
    OAuthModule.forRoot(),
    AngularFontAwesomeModule

    /* Documentation Modules */ // TODO Conditionally compilation / dont add to prod mode??
    // ...DEMOS
  ],
  providers: [
    /* Angular Providers */
    DatePipe,

    /* Shared Providers */
    ConfigService,
    ConsoleLogger,
    TranslateService,
    TranslationLoaderService,
    // AutoLogoutService,
    {
      provide: NgbDateParserFormatter,
      useClass: NgbDateFormatter
    },
    // {
    //     provide: NgbTimeAdapter2,
    //     useClass: NgbTimeStringAdapter
    // },
    {
      provide: NgbDateAdapter,
      useClass: NgbNativeDateAdapter
    },
    {
      provide: Logger,
      useExisting: ConsoleLogger
    },
    {
      provide: ErrorHandler,
      useClass: GlobalErrorHandler
    },

    /* Core Providers */
    AuthGuard,
    {
      provide: 'ORIGIN_URL',
      useFactory: originFactory
    },
    {
      provide: APP_INITIALIZER,
      useFactory: appInitializer,
      deps: [
        ConfigService,
        TranslateService,
        TranslationLoaderService
        // AutoLogoutService
      ],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthHttpInterceptor,
      deps: [OAuthService, ActiveXService],
      multi: true
    },

    /* Route Resolvers */
    DelayComponentLoadingResolver
  ],
  entryComponents: [IdleLogoutComponent],
  bootstrap: [AppComponent]
})
export class AppModule {}
