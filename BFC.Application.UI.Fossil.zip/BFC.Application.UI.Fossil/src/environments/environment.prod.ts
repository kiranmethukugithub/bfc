export const environment = {
  production: true,
  configFile: '/assets/config/app-config.json'
};
