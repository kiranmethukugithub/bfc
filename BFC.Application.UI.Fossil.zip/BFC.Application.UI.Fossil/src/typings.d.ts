/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}

declare var ActiveXObject: ActiveXObject; 
interface ActiveXObject {
  new (objectName: string);
  new (objectName: string, location: string);
}

declare var GKComSysDetails: GKComSysDetails;
interface GKComSysDetails extends ActiveXObject {
  GetSysName(): string;
  GetLocIPAddress(): string;
  GetMACAddress(): string;
  GetProcessorId(): string;
  GetAllSysPrinterName(): string;
}

interface Printing {
  Orientation: "landscape" | "portrait" | string;
}

interface ScriptX {
  Printing: Printing

}

interface MeadCo {
  ScriptX: ScriptX
}

declare var MeadCo: any;
