param($version = "0.0.0-dev")

. .\json-util.ps1

Push-Location
Set-Location "$PSScriptRoot\..\"

$PackagesJsonFilename = "package.json"

$PackageJson = Get-Content $PackagesJsonFilename -raw | ConvertFrom-Json
$PackageJson.version = $version
$PackageJson | ConvertTo-Json -Depth 20 | Format-Json | Set-content $PackagesJsonFilename

Pop-Location
