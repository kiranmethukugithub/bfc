param($version = "0.0.0-dev")

Push-Location
Set-Location "$PSScriptRoot\..\"

& npm install --loglevel=error
& ng build --prod --no-progress
try {
  & cordova platform add android
} catch {
  # Ignore Errors, as buidling locally - you will have already added the platform.
  # The next step will report if you havent executed the above command successfully...
}
& cordova build android #--release

New-Item -ItemType Directory -Path "build" -Force
#Copy-Item ".\platforms\android\app\build\outputs\apk\release\app-release-unsigned.apk" -Destination "build\seismic-android-v$version.apk"
Copy-Item ".\platforms\android\app\build\outputs\apk\debug\app-debug.apk" -Destination "build\Seismic.Android.$version.apk"

Pop-Location
