Push-Location
Set-Location "$PSScriptRoot\..\build"

$files = @(Get-ChildItem -Path "..\build" -Filter "*.apk")

if($files.Length -eq 1) {
  Write-Host "Installing..." -ForegroundColor Green
  adb install -r $files[0].Name

} else {
  Write-Host "User action require..." -ForegroundColor Yellow
  $fileChoices = @()

  for ($i=0; $i -lt $files.Count; $i++) {
    $fileChoices += [System.Management.Automation.Host.ChoiceDescription]("$($files[$i].Name) &$($i+1)`n")
  }

  $userChoice = $host.UI.PromptForChoice('Multiple builds detected.', 'Choose a file:', $fileChoices, 0);
  adb install -r "$($files[$userChoice].Name)"
}

Write-Host "Open your app and use chrome to inspect your device using:"
Write-Host "chrome://inspect/#devices" -ForegroundColor Blue

Pop-Location

