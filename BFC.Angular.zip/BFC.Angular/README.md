# Seismic eCommerce

## Description

This the Seismic eCommerce front end / admin application, built using Angular 6 and Cordova.

## Project Structure

```
seismic/
|
├── build/
|   └── * Custom Build Output from CI / Scripts
├── e2e/
|   └── * Angular End-To-End Tests
├── hooks/
|   └── * Cordova Hooks
├── node_modules/
|   └── * NPM Packages
├── platforms/
|   └── * Cordova Platforms
├── plugins/
|   └── * Cordova Plugins
├── res/
|   └── * Cordova Resources
├── scripts/
|   └── * Automation Scripts
├── src/
|   └── * Angular Application Source Code
├── www/
|   └── * Angular generated build output *
├── .editorconfig     * Editor Extension Config
├── .gitignore        * Git Ignore File
├── .npmignore        * NPM Packaging Ignore File
├── angular.json      * Angular Config
├── config.xml        * Cordova Config
├── package-lock.json * NPM Generated File used for Optimizing installations
├── package.json      * NPM Package Manifest
├── README.md         * This file
├── tsconfig.json     * TypeScript Config
├── tslint.json       * TypeScript Lint Configuration>
└── web.config        * IIS Web Config File
```

<!-- 
  Tree Characters:
      |
      ├──
      └──
-->

## Scripts

- `build-android.ps1` - Builds the application for the Android Environment producing an APK.

- `build-iis.ps1` - Build the application and packages it for use in IIS, with an acompanying Web.config and setup script (setup-iis.ps1).

- `clean-project.ps1` - Removes all generated build output from the project directory.

- `json-util.ps1` - contains a few powershell methods for dealing with JSON related content.

- `version.ps1` - edits the version number throughout your application.

## List of 3rd Party Libraries Used.

- Angular 7
- RxJS
- Lodash
- NgBootstrap
- Bootstrap 4 CSS
- Cordova
- Compodoc

# Developer Environment Setup

## Android / Cordova Setup

- Install [Cordova](https://cordova.apache.org/#getstarted) Globally
- Install [Android Studio](https://developer.android.com/studio/)
- Ensure you have configured your [Java Environment Variables](https://stackoverflow.com/a/26640589/985856)

- Ensure you have configured android tools in PATH environment variable.
`C:\Program Files (x86)\Android\android-sdk\platform-tools`

One time setup for android studio
- Create an empy android project, selecting the minimum API version you wish to target and allow it to restore / build the project.
- Setup your phone for [wireless debugging](https://stackoverflow.com/a/10236938/985856)
- Test that you are able to push the APK to the phone.