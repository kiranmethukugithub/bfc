param($version = "0.0.0-dev")

Push-Location
Set-Location "$PSScriptRoot\..\"

& npm install --loglevel=error
& ng build --prod --no-progress
Copy-Item "web.config" -Destination "www\web.config"

New-Item -ItemType Directory -Path "build" -Force
Compress-Archive -Path "www\*" -DestinationPath "build\Seismic.Web.$version.zip" -CompressionLevel Optimal -Force

Pop-Location

