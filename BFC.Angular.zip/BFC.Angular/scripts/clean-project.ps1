Push-Location
Set-Location "$PSScriptRoot\..\"

$NodeModulesFolder = "node_modules";
$BuildOutputFolder = "build"
$CordovaPLatformsFolder = "platforms"
$CordovaPluginsFoldler = "plugins"
$AngularBuildOutputFolder = "www"
$DocumentationFolder = "documentation"

if(Test-Path -Path $DocumentationFolder) {
  Remove-Item -Force -Recurse -Path $DocumentationFolder
}
if(Test-Path -Path $NodeModulesFolder) {
  Remove-Item -Force -Recurse -Path $NodeModulesFolder
}
if(Test-Path -Path $BuildOutputFolder) {
  Remove-Item -Force -Recurse -Path $BuildOutputFolder
}
if(Test-Path -Path $CordovaPLatformsFolder) {
  Remove-Item -Force -Recurse -Path $CordovaPLatformsFolder
}
if(Test-Path -Path $CordovaPluginsFoldler) {
  Remove-Item -Force -Recurse -Path $CordovaPluginsFoldler
}
if(Test-Path -Path $AngularBuildOutputFolder) {
  Remove-Item -Force -Recurse -Path $AngularBuildOutputFolder
}

Pop-Location
