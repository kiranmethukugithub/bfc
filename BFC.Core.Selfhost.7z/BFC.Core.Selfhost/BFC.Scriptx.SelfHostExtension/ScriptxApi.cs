﻿using Microsoft.Owin.Hosting;
using System;
using System.Configuration;

namespace BFC.Core.Selfhost
{
    public class ScriptxApi
    {
        IDisposable webServer;

        readonly string selfhostserviceUrl = ConfigurationManager.AppSettings["selfhostserviceurl"];

        public ScriptxApi()
        {

        }
        public void Start()
        {
            this.webServer = WebApp.Start<StartUp>(url: selfhostserviceUrl);

        }

        public void Stop()
        {
            this.webServer.Dispose();
        }
    }
}
