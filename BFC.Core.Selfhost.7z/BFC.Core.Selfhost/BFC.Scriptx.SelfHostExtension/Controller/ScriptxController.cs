﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Web.Http;

namespace BFC.Core.Selfhost.Controller
{
    public class ScriptxController : ApiController
    {
        /// <summary>
        /// Gets the System machine name.
        /// </summary>
        /// <returns>The Machine name.</returns>
        [HttpGet]
        public IHttpActionResult GetMachineName()
        {
            return Ok(this.GetSystemMachineName());
        }

        /// <summary>
        /// Gets the MAC address of the first operation NIC found.
        /// </summary>
        /// <returns>The MAC address.</returns>
        [HttpGet]
        public IHttpActionResult GetMacAddress()
        {
            return Ok(this.GetSystemMacAddress());
        }

        /// <summary>
        /// Gets the current process id of the system.
        /// </summary>
        /// <returns>The Process Id.</returns>
        [HttpGet]
        public IHttpActionResult GetProcessId()
        {
            return Ok(this.GetSystemProcessId());
        }

        /// <summary>
        /// Gets the IP address of the system.
        /// </summary>
        /// <returns>The IP Address.</returns>
        [HttpGet]
        public IHttpActionResult GetIpAddress()
        {
            return Ok(this.GetSystemIpAddress());
        }


        /// <summary>
        /// Finds the System machine name.
        /// </summary>
        /// <returns>The Machine name.</returns>
        private string GetSystemMachineName()
        {
            return Environment.MachineName;
        }

        /// <summary>
        /// Finds the MAC address of the first operation NIC found.
        /// </summary>
        /// <returns>The MAC address.</returns>
        private string GetSystemMacAddress()
        {
            string macAddresses = string.Empty;
            foreach (NetworkInterface nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.NetworkInterfaceType != NetworkInterfaceType.Ethernet) continue;
                if (nic.OperationalStatus == OperationalStatus.Up)
                {
                    macAddresses += nic.GetPhysicalAddress().ToString();
                    break;
                }
            }
            return macAddresses;
        }

        /// <summary>
        /// Finds the current process id of the system.
        /// </summary>
        /// <returns>The Process Id.</returns>
        private string GetSystemProcessId()
        {
            Process currentProcess = Process.GetCurrentProcess();
            return currentProcess.Id.ToString();
        }

        /// <summary>
        /// Finds the IP address of the system.
        /// </summary>
        /// <returns>The IP Address.</returns>
        private string GetSystemIpAddress()
        {
            string ipAddress = string.Empty;
            var host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (var ip in host.AddressList)
            {
                if (ip.AddressFamily == AddressFamily.InterNetwork)
                {
                    ipAddress = ip.ToString();
                }
            }
            return ipAddress;
        }
    }
}
