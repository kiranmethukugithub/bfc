﻿using Topshelf;

namespace BFC.Core.Selfhost
{
    class Program
    {
        static void Main(string[] args)
        {
            HostFactory.Run(topShelf =>
            {
                topShelf.Service<ScriptxApi>(p =>
                {
                    p.ConstructUsing(name => new ScriptxApi());
                    p.WhenStarted(tc => tc.Start());
                    p.WhenStopped(tc => tc.Stop());
                });
                topShelf.RunAsLocalSystem();
                topShelf.SetDescription("BFC.Scriptx.Selfhost");
                topShelf.SetDisplayName("BFC.Scriptx.Selfhost");
                topShelf.SetServiceName("BFC.Scriptx.Selfhost");
            });
        }
    }
}
