﻿using System;
using System.Diagnostics;
using WixSharp;
using WixSharp.CommonTasks;

namespace BFC.Selfhost.Installer
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Compiler.WixLocation = @"..\packages\WixSharp.wix.bin.3.11.0\tools\bin";
                var project = new ManagedProject("BFC.Scriptx.Selfhost"
                    , new Dir(
                        $@"{Environment.ExpandEnvironmentVariables("%programfiles(x86)%")}\BFC.Scriptx.Selfhost"
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\BFC.Scriptx.Selfhost.exe")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.AspNetCore.Http.Abstractions.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.AspNetCore.Http.Extensions.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.AspNetCore.Http.Features.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Extensions.Configuration.Abstractions.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Extensions.DependencyInjection.Abstractions.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Extensions.FileProviders.Abstractions.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Extensions.Logging.Abstractions.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Extensions.Options.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Extensions.Primitives.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Net.Http.Headers.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Owin.Cors.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Owin.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Owin.Host.HttpListener.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Microsoft.Owin.Hosting.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Newtonsoft.Json.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Owin.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.ComponentModel.Annotations.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Configuration.ConfigurationManager.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Memory.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Net.Http.Formatting.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Numerics.Vectors.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Runtime.CompilerServices.Unsafe.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Security.AccessControl.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Security.Permissions.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Security.Principal.Windows.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Text.Encodings.Web.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Web.Cors.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Web.Http.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\System.Web.Http.Owin.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\Topshelf.dll")
                        , new File($@"..\BFC.Scriptx.SelfHostExtension\bin\Debug\BFC.Scriptx.Selfhost.exe.config")
                        )
                    );
                project.BeforeInstall += Project_BeforeInstall;
                project.AfterInstall += Project_AfterInstall;
                Compiler.BuildMsi(project);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void Project_BeforeInstall(SetupEventArgs e)
        {
            if (e.IsUninstalling)
            {
                Tasks.StopService("BFC.Scriptx.Selfhost");
                Process proc = new Process();
                proc.StartInfo.FileName = $@"{Environment.ExpandEnvironmentVariables("%programfiles(x86)%")}\BFC.Scriptx.Selfhost\BFC.Scriptx.Selfhost.exe";
                proc.StartInfo.Arguments = "uninstall";
                proc.StartInfo.Verb = "runas";
                proc.Start();
            }
        }

        private static void Project_AfterInstall(SetupEventArgs e)
        {
            if (e.IsInstalling)
            {
                Process proc = new Process();
                proc.StartInfo.FileName = $@"{Environment.ExpandEnvironmentVariables("%programfiles(x86)%")}\BFC.Scriptx.Selfhost\BFC.Scriptx.Selfhost.exe";
                proc.StartInfo.Arguments = "install start";
                proc.StartInfo.Verb = "runas";
                proc.Start();
            }
        }
    }
}
